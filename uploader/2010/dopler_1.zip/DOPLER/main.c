//ICC-AVR application builder : 13.09.2008 11:20:34
// Target : M128
// Crystal: 16.000Mhz



#include <iom128v.h>
#include <macros.h>

//#include <math.h>


void perecl(void);
unsigned char  arc (unsigned int D);
char byte_count =0;
char col =0;
int buff[200];
int ug[10];
int tem=0;
int ADC_VALUE=0;
long A=0;
long B=0;
char temp=0;
unsigned int U[10];
char p=0;
//
char count=0;

int pogr=10;

//
const unsigned int arct[91]=
{0, 2, 4, 7, 9, 11, 13, 16, 18, 20, 23, 25, 27, 30,
 32, 34, 37, 39, 42, 44, 47, 49, 52, 54, 57, 60, 62,
  65, 68, 71, 74, 77, 80, 83, 86, 90, 93, 96, 100,
   104, 107, 111, 115, 119, 124, 128, 133, 137, 142,
    147, 153, 158, 164, 170, 176, 183, 190, 197, 205,
	 213, 222, 231, 241, 251, 262, 274, 287, 302, 317,
	  333, 352, 372, 394, 419, 446, 478, 513, 554, 602,
	   659, 726, 808, 911, 1042, 1218, 1463, 1830, 2442,
	    3665, 7333,  10000 };//*64
		
const int cos_m[9]={0, 8, 6, 0, -6, -8, -6, 0, 6};//*8
const int sin_m[9]={0, 0, 6, 8, 6, 0, -6, -8, -6};//*8

void port_init(void)
{
 PORTA = 0xAA;
 DDRA  = 0xFF;
 PORTB = 0x00;
 DDRB  = 0x00;
 PORTC = 0x00; //m103 output only
 DDRC  = 0x00;
 PORTD = 0x00;
 DDRD  = 0x00;
 PORTE = 0x00;
 DDRE  = 0x00;
 PORTF = 0x00;
 DDRF  = 0x00;
 PORTG = 0x00;
 DDRG  = 0x00;
}




//UART0 initialize
// desired baud rate: 57600
// actual: baud rate:58824 (2,1%)
// char size: 8 bit
// parity: Disabled
void uart0_init(void)
{
 UCSR0B = 0x00; //disable while setting baud rate
 UCSR0A = 0x00;
 UCSR0C = 0x06;
 UBRR0L = 0x10; //set baud rate lo
 UBRR0H = 0x00; //set baud rate hi
 UCSR0B = 0xD8;
}

#pragma interrupt_handler uart0_rx_isr:iv_USART0_RXC
void uart0_rx_isr(void)
{
 //uart has received a character in UDR
}

#pragma interrupt_handler uart0_tx_isr:iv_USART0_TXC
void uart0_tx_isr(void)
{

if (byte_count>=col) byte_count=0;else UDR0=buff[byte_count],byte_count++;
}


//TIMER0 initialize - prescale:32
// WGM: Normal
// desired value: 4000Hz
// actual value: 4000,000Hz (0,0%)
void timer0_init(void)
{
 TCCR0 = 0x00; //stop
 ASSR  = 0x00; //set async mode
 TCNT0 = 0x83; //set count
 OCR0  = 0x7D;
 TCCR0 = 0x03; //start timer
}

#pragma interrupt_handler timer0_ovf_isr:iv_TIM0_OVF
void timer0_ovf_isr(void)
{
 TCNT0 = 0x83; //reload counter value
 PORTA=(1<<p);
 
 ADCSRA |= 0x40;
 p++;
 
 
}

//ADC initialize
// Conversion time: 104uS
void adc_init(void)
{
 ADCSRA = 0x00; //disable adc
 ADMUX = 0x00; //select adc input 0
 ACSR  = 0x80;
 ADCSRA = 0x8A;
}

#pragma interrupt_handler adc_isr:iv_ADC
void adc_isr(void)
{
 ADC_VALUE=ADCL;//conversion complete, read value (int) using...            //Read 8 low bits first (important)
 ADC_VALUE|=(int)ADCH<<8 ; //read 2 high bits and shift into top byte
 

A+=(ADC_VALUE*cos_m[p]);
B+=(ADC_VALUE*sin_m[p]);
if (p>7)perecl();


}

//call this routine to initialize all peripherals
void init_devices(void)
{
 //stop errant interrupts until set up
 CLI(); //disable all interrupts
 XDIV  = 0x00; //xtal divider
 XMCRA = 0x00; //external memory
 port_init();
timer0_init();
 uart0_init();
adc_init();

 MCUCR = 0x00;
 EICRA = 0x00; //extended ext ints
 EICRB = 0x00; //extended ext ints
 EIMSK = 0x00;
 TIMSK = 0x01; //timer interrupt sources
 ETIMSK = 0x00; //extended timer interrupt sources
 SEI(); //re-enable interrupts
 //all peripherals are now initialized
}

//
void main(void)
{
init_devices();

/*
a=(cos((89*_PI)/180))*1000;
���� �>B � A>-B, �� Phi = arctg(B/A);
���� �<B � A>-B, �� Phi = 90 ����. - arctg(A/B);
���� �<B � A<-B, �� Phi = arctg(B/A) + 180 ����.;
���� �>B � A<-B, �� Phi = 270 ����. - arctg(B/A);

//insert your functional code here...*/
}

void perecl(void)
{
static int old_Phi;
static  long old_A,old_B;
int Phi;

p=0;

if ((old_A+pogr<A)||(A+pogr<old_A)||(old_B+pogr<B) || (B+pogr<old_B)) 
count=0;else 
{
count++;
}

old_A=A;
old_B=B;

if (count >=15)
{
count=15;
if (B>0)
{
if (A>0)
{
A=abs(A);
B=abs(B);
Phi = arc((B<<7)/A);
}else
if (A<0)
{
A=abs(A);
B=abs(B);
Phi =180-arc((B<<7)/A);
}
}else
if (B<0)
{
if (A>0)
{
A=abs(A);
B=abs(B);
Phi = 359-arc((B<<7)/A);
}else
if (A<0)
{
A=abs(A);
B=abs(B);
Phi =180+arc((B<<7)/A);
}
}

if (old_Phi!=Phi)
if (!byte_count)
{
old_Phi=Phi;
buff[0]='U';
buff[1]='=';
buff[2]=(Phi/100)+0x30;
buff[3]=((Phi%100)/10)+0x30;
buff[4]=(Phi%10)+0x30;
buff[5]=0x0D;
col=6;
uart0_tx_isr();
}
}
A=0;
B=0;

}

unsigned char  arc (unsigned int D)
{

unsigned char i;
unsigned char toLeft=0;
unsigned char toRight=89;
unsigned char pol0=0;
unsigned char pol1=0;

	

while (1)
	{
	
	
		i=(toLeft+toRight) / 2;
		if (D < arct[i])
		{
			toRight= i-1;
			pol1 = i;
			
		}
		else if (D > arct[i])
		{
			toLeft= i+1;
			pol0=i;
			
		}
		if ((((pol0-pol1)<2)&&(pol0)&&(pol1))||(toLeft > toRight)||(D == arct[i]) ) break; 
		
	}
return i;
	
}
void putchar(unsigned char data )//��� ��������
{
  
   while ( !( UCSR0A & (1<<UDRE0)) );
  
    UDR0 = data;
}
// ��� ����� �����/��������

void putchar1(unsigned char data )//���2 ��������
{
  
    while ( !( UCSR1A & (1<<UDRE1)) );
  
    UDR1 = data;
}



unsigned char getchar0( void )// ���1 ����� 
{

while ( !(UCSR0A & (1<<RXC0)) );
return UDR0;
}
unsigned char getchar1( void )// ��� 2 �����
{

while ( !(UCSR1A & (1<<RXC1)) );
return UDR1;
}


