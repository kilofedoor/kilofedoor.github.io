
import datetime
import re

a='<?xml version=\"1.0\" encoding=\"UTF-8\"?><kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document>'
z='</Document></kml>'
#valsa=[[u'SU0107', u'144512', u'33.4542E 55.5058N;', u'user', u'', u''], [u'SD0107', u'144512', u'32.4542E 52.5058N;', u'Beta', u'', u''], [u'SD0107', u'144512', u'31.4542E 51.5058N;', u'Beta', u'', u''], [u'SD0107', u'144512', u'38.4542E 50.5058N;', u'Beta', u'', u''], [u'WW2107', u'144512', u'34.4542E 59.5058N;', u'Beta', u'', u''], [u'WW2107', u'144512', u'37.4542E 51.5058N;', u'Beta', u'', u''], [u'SU0107', u'144512', u'32.4542E 51.5058N;', u'Beta', u'', u''], [u'SU0107', u'144512', u'35.4542E 53.5058N;', u'user', u'', u'']]

def getAir(code):
    file = open('aircode.txt', 'r')
    for line in file:
        match = re.search('\,(%s)\,*'%code,line)
        if match:
            return line.split(',')


def setPoint(vals):
    for i in xrange(len(vals)):
        vals[i][1]= regex(vals[i][1])
        vals[i][2]= coord(vals[i][2])

    res=a
    b1='''<Style id="sh_placemark_circle_highlight"><IconStyle><color>ff00ffff</color><scale>1.2</scale>
            <Icon><href>http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png</href>
            </Icon></IconStyle><ListStyle></ListStyle></Style><Style id="sn_placemark_circle">
            <IconStyle><color>ff00ffff</color><scale>1.2</scale><Icon><href>http://maps.google.com/mapfiles/kml/shapes/placemark_circle.png</href>
            </Icon></IconStyle><ListStyle></ListStyle></Style>
            <StyleMap id="msn_placemark_circle"><Pair><key>normal</key><styleUrl>#sn_placemark_circle</styleUrl>
            </Pair><Pair><key>highlight</key><styleUrl>#sh_placemark_circle_highlight</styleUrl></Pair></StyleMap>'''
    b2='''<Style id="sh_placemark_circle_highlight"><IconStyle><color>ff00aa00</color><scale>1.2</scale>
            <Icon><href>http://maps.google.com/mapfiles/kml/shapes/placemark_circle_highlight.png</href>
            </Icon></IconStyle><ListStyle></ListStyle></Style><Style id="sn_placemark_circle">
            <IconStyle><color>ff00aa00</color><scale>1.2</scale><Icon><href>http://maps.google.com/mapfiles/kml/shapes/placemark_circle.png</href>
            </Icon></IconStyle><ListStyle></ListStyle></Style>
            <StyleMap id="msn_placemark_circle"><Pair><key>normal</key><styleUrl>#sn_placemark_circle</styleUrl>
            </Pair><Pair><key>highlight</key><styleUrl>#sh_placemark_circle_highlight</styleUrl></Pair></StyleMap>'''
    rs=[]
    yellow={}
    for st in vals:
        if yellow.has_key(st[0]):
            pname = '_'
        else:
            yellow[st[0]]=1
            pname = st[0]
        c=r'''<Placemark id="%s"><name>%s</name><description><![CDATA[<div style="font-size:larger">Bort:%s<br> %sUTC User :%s  %s  %s'''%(st[0],pname,st[0],st[1],st[3],st[4][1:],st[5])
        res+=c       
        if len(st[4])>3:
            photo=r'''<a href="http://www.airliners.net/search/photo.search?aircraftsearch=&airlinesearch=&placesearch=&countrysearch=&adv_remark=&photographersearch=&emailsearch=&regsearch=%s&cnsearch=&codesearch=&datesearch=&id=&yearsearch=&specialsearch=&specialsearch2=&sort_order=aircraft&page_limit=1&thumbnails=noinfo&advanced_search=true&engine_version=6.0">Photo</a>'''%st[4][1:]
            res+=photo
        now = datetime.datetime.now()
        dt=now.date()
        fa=''
        fbt=''
        fb=''
        for ch in st[0]:
            if not ch.isdigit():
                fa+=ch
            else:
                fbt+=ch
        flg=True
        for nm in fbt:
            if int(nm)<1 and flg:
                pass
            else:
                flg=False
                fb+=nm
        fa = fa.replace(' ','')
        fb = fb.replace(' ','')
        air=getAir(fa)
        if air:
            res+='<br>'+'AIRLINE: '+air[0]+'<br>'
            if len(air)>3:
                res+=  'Call signal: '+air[3]+'<br>'
        airports=r'''<a href="http://mobile.flightstats.com/go/Mobile/flightStatusByFlightProcess.do?airlineCode=%s&flightNumber=%s&departureDate=%s&submit=Submit">Airports</a>'''%(fa,fb,str(dt))
        res+=airports    
        endp='</div>]]></description>'
        res+=endp
        if (st[0] in rs):
            res+=b1
        else:
            res+=b2
            rs.append(st[0])
        d='''<Point><coordinates>%s</coordinates></Point></Placemark>'''%st[2]
        res+=d
    hesh={}
    for sl in vals:
        if hesh.has_key(sl[0]):
            hesh[sl[0]]+=sl[2]+',0 '
        else:
            hesh[sl[0]]=sl[2]+',0 '

    for vl in hesh.keys():
        v=hesh.get(vl)
        e='''<Placemark><name>%s</name><styleUrl>#msn_ylw-pushpin</styleUrl>
                <Style id="linestyleExample"><LineStyle><colorMode>random</colorMode><width>2</width>
                </LineStyle></Style><LineString><tessellate>4</tessellate><coordinates>
                %s</coordinates></LineString></Placemark>'''%(vl,v)
        res+=str(e)
    res+=z
    kml=open('Point.kml', 'w')
    kml.write(res)
    kml.close()



def regex(val):
    if ':' in val:
        return val
    else:
        i=0
        x=''
        for tm in val:
            if i%2 and i<5:
                x+=(tm+':')
            else:
                x+=tm
            i+=1
        return x

def coord(s):
    if '+'in s or '-' in s:
        return s
    else:
        s = s.replace('S','-')
        s = s.replace('W','-')
        s = s.replace('N','+')
        s = s.replace('E','+')
        s = s.replace(';','')
        s = s.replace(' ',',')
        #33.4542+,55.5058+
        b=s[-1]
        a=s[s.index(',')-1]
        s=s.replace('-','')
        s=s.replace('+','')
        s=a+s;
        s=s[:s.index(',')+1]+b+s[s.index(',')+1:]
        return s


