//ICC-AVR application builder : 13.09.2008 11:20:34
// Target : M128
// Crystal: 16.000Mhz



#include <iom128v.h>
#include <macros.h>

//#include <math.h>


void perecl(void);
unsigned char  arc (unsigned int D);
char byte_count =0;
char col =0;
int buff[200];
int ug[10];
int tem=0;
char temp=0;
unsigned int U[10];
char p=0;
const unsigned int arct[91]=
{0, 2, 3, 5, 7, 9, 11, 12, 14, 16, 18, 19, 21, 23, 25, 27, 29, 31, 32, 34, 36,
 38, 40, 42, 45, 47, 49, 51, 53, 55, 58, 60, 62, 65, 67, 70, 73, 75, 78, 81, 
 84, 87, 90, 93, 97, 100, 104, 107, 111, 115, 119, 123, 128, 133, 138, 143, 
 148, 154, 160, 166, 173, 180, 188, 196, 205, 214, 225, 236, 248, 261, 275,
  290, 308, 327, 349, 373, 401, 433, 470, 514, 567, 631, 712, 814, 951, 1143,
   1430, 1908, 2864, 5729, 10000 };


void port_init(void)
{
 PORTA = 0xAA;
 DDRA  = 0xFF;
 PORTB = 0x00;
 DDRB  = 0x00;
 PORTC = 0x00; //m103 output only
 DDRC  = 0x00;
 PORTD = 0x00;
 DDRD  = 0x00;
 PORTE = 0x00;
 DDRE  = 0x00;
 PORTF = 0x00;
 DDRF  = 0x00;
 PORTG = 0x00;
 DDRG  = 0x00;
}




//UART0 initialize
// desired baud rate: 57600
// actual: baud rate:58824 (2,1%)
// char size: 8 bit
// parity: Disabled
void uart0_init(void)
{
 UCSR0B = 0x00; //disable while setting baud rate
 UCSR0A = 0x00;
 UCSR0C = 0x06;
 UBRR0L = 0x10; //set baud rate lo
 UBRR0H = 0x00; //set baud rate hi
 UCSR0B = 0xD8;
}

#pragma interrupt_handler uart0_rx_isr:iv_USART0_RXC
void uart0_rx_isr(void)
{
 //uart has received a character in UDR
}

#pragma interrupt_handler uart0_tx_isr:iv_USART0_TXC
void uart0_tx_isr(void)
{

if (byte_count>=col) byte_count=0;else UDR0=buff[byte_count],byte_count++;
}


//TIMER0 initialize - prescale:32
// WGM: Normal
// desired value: 2000Hz
// actual value: 2000,000Hz (0,0%)
void timer0_init(void)
{
 TCCR0 = 0x00; //stop
 ASSR  = 0x00; //set async mode
 TCNT0 = 0x06; //set count
 OCR0  = 0xFA;
 TCCR0 = 0x03; //start timer
}

#pragma interrupt_handler timer0_ovf_isr:iv_TIM0_OVF
void timer0_ovf_isr(void)
{
 TCNT0 = 0x06; //reload counter value
 PORTA=(1<<p);
 
 ADCSRA |= 0x40;
 p++;
 
 
}

//ADC initialize
// Conversion time: 104uS
void adc_init(void)
{
 ADCSRA = 0x00; //disable adc
 ADMUX = 0x20; //select adc input 0
 ACSR  = 0x80;
 ADCSRA = 0x8C;
}

#pragma interrupt_handler adc_isr:iv_ADC
void adc_isr(void)
{
 //conversion complete, read value (int) using...            //Read 8 low bits first (important)
 U[p-1]=ADCH ; //read 2 high bits and shift into top byte
if (p>3)perecl();


}

//call this routine to initialize all peripherals
void init_devices(void)
{
 //stop errant interrupts until set up
 CLI(); //disable all interrupts
 XDIV  = 0x00; //xtal divider
 XMCRA = 0x00; //external memory
 port_init();
timer0_init();
 uart0_init();
adc_init();

 MCUCR = 0x00;
 EICRA = 0x00; //extended ext ints
 EICRB = 0x00; //extended ext ints
 EIMSK = 0x00;
 TIMSK = 0x01; //timer interrupt sources
 ETIMSK = 0x00; //extended timer interrupt sources
 SEI(); //re-enable interrupts
 //all peripherals are now initialized
}

//
void main(void)
{
init_devices();

/*
a=(cos((89*_PI)/180))*1000;
���� �>B � A>-B, �� Phi = arctg(B/A);
���� �<B � A>-B, �� Phi = 90 ����. - arctg(A/B);
���� �<B � A<-B, �� Phi = arctg(B/A) + 180 ����.;
���� �>B � A<-B, �� Phi = 270 ����. - arctg(B/A);

//insert your functional code here...*/


}




void perecl(void)
{
unsigned int Phi;
unsigned int Phi_0;

char i;
int out=0;
p=0;
if (U[0]==U[2])

{
if (U[1]>U[3]) Phi=90;
if (U[1]<U[3]) Phi=270;
}
else

if (U[1]==U[3])

{
if (U[0]>U[2]) Phi=0;
if (U[0]<U[2]) Phi=180;
}
else
{
if (U[0]>U[2])
{
if (U[1]>U[3]) 
{
Phi_0=(((U[1]-U[3])*100)/((U[0]-U[2])));
Phi =0;
}else 
{
Phi_0=(((U[0]-U[2])*100)/((U[3]-U[1])));
Phi =270;
}

}else
if (U[0]<U[2])
{
if (U[1]<U[3])
{
Phi_0=(((U[3]-U[1])*100)/((U[2]-U[0])));
Phi =180;
}else
{
Phi_0=(((U[2]-U[0])*100)/((U[1]-U[3])));
Phi =90;
}
}

Phi += arc(Phi_0);
}
if (!byte_count)
{
ug[0]=Phi;
buff[0]='U';
buff[1]='g';
buff[2]='o';
buff[3]='l';
buff[4]='=';
buff[5]=(Phi/100)+0x30;
buff[6]=((Phi%100)/10)+0x30;
buff[7]=(Phi%10)+0x30;
UDR0=13;
col=8;
}
/*
for (i=0;i<18;i++)
{
ug[i+1]=ug[i];
out+=ug[i];
}
out=(out+ug[9])/20;
if (tem>21)
{tem=0;
buff[0]='U';
buff[1]='g';
buff[2]='o';
buff[3]='l';
buff[4]='=';
buff[5]=(out/100)+0x30;
buff[6]=((out%100)/10)+0x30;
buff[7]=(out%10)+0x30;
UDR0=0x0D;
col=8;
}else tem++;
*/



}


unsigned char  arc (unsigned int D)
{

unsigned char i;
unsigned char toLeft=0;
unsigned char toRight=89;
unsigned char pol0=0;
unsigned char pol1=0;

	
 
while (1)
	{
	
	
		i=(toLeft+toRight) / 2;
		if (D < arct[i])
		{
			toRight= i-1;
			pol1 = i;
			
		}
		else if (D > arct[i])
		{
			toLeft= i+1;
			pol0=i;
			
		}
		if ((((pol0-pol1)<2)&&(pol0)&&(pol1))||(toLeft > toRight)||(D == arct[i]) ) break; 
		
	}
return i;
	
}
void putchar(unsigned char data )//��� ��������
{
  
   while ( !( UCSR0A & (1<<UDRE0)) );
  
    UDR0 = data;
}
// ��� ����� �����/��������

void putchar1(unsigned char data )//���2 ��������
{
  
    while ( !( UCSR1A & (1<<UDRE1)) );
  
    UDR1 = data;
}



unsigned char getchar0( void )// ���1 ����� 
{

while ( !(UCSR0A & (1<<RXC0)) );
return UDR0;
}
unsigned char getchar1( void )// ��� 2 �����
{

while ( !(UCSR1A & (1<<RXC1)) );
return UDR1;
}


