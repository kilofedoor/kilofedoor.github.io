function autorefresh(varargin)
if ~nargin
    return          % Error running.
end
handles = varargin{1};
if  nargin == 2
    addr = varargin{2};
else
    addr = 'nothing';
end
if  strcmp(addr, 'life')
    return          % This Button Blocked yet.
end
dat_len = 57600;
name_dat = 'D:\SYSTEM\MATLAB\work\HF_rec_newest\My_Signals\my_in.dat';
sig_len = 3;
f_s = 9600;
[fo_min, fo_max] = deal(8000, 19200);
[sig_leno_min, sig_leno_max] = deal(1, 10);
prec = 1e-7;            % Set limit of precision of  rhos  measurement.
% Get Variator Mode.
var_modes = {'manual', 'magnetic', 'optimal'};
mode_vec = find(cell2mat(get(handles.mode,'Value')));
var_mode = var_modes{mode_vec};
% Read/Correct Checkbox Values (Points).
pts_vec = cell2mat(get(handles.num_pts,'Value'));
if  strncmp(addr, 'checkbox', 8)                % Check ON/OFF Points.
    num_act = str2num(addr(9:end));             % Number of changed Point.
    if  strcmp(var_mode, 'magnetic')
        if ~sum(pts_vec)
            set(handles.num_pts(num_act),'Value',1)
            pts_vec = zeros(4, 1);
            pts_vec(num_act) = 1;
        end
    elseif strcmp(var_mode, 'optimal')
        indx_zero = find([1:4] ~= num_act);     % Just single Point is ON.
        pts_vec(indx_zero) = 0;
        set(handles.num_pts(indx_zero),'Value',0)
        pts_vec(num_act) = 1;
        set(handles.num_pts(num_act),'Value',1)
        set(handles.pts(indx_zero),'Visible','of')
        set(handles.txs(indx_zero),'Visible','of')
    end
    ofon = ['of'; 'on'];
    state = ofon(get(handles.num_pts(num_act),'Value')+1, :);
    set(handles.pts(num_act),'Visible',state)
    set(handles.txs(num_act),'Visible',state)
elseif strcmp(addr, 'reset')
    for n = 1:4
        set(handles.num_pts(n),'Value',1)
    end
    set(handles.pts,'Visible','on')
    set(handles.txs,'Visible','on')
    pts_vec = ones(4, 1);
end
% Check Variator Mode.
switch var_mode
    case 'manual'
        set(handles.mode(2),'TooltipString', 'magnetic tuning the Properties');
        set(handles.mode(3),'TooltipString', 'optimal tuning the Properties');
        % Unfreeze disabled elements.
        freezel(handles, 'on')
    case 'magnetic'
        set(handles.mode(1),'TooltipString', 'manual tuning the Properties');
        set(handles.mode(3),'TooltipString', 'optimal tuning the Properties');
        if ~sum(pts_vec)
            uiwait(errordlg(sprintf(['Magnetic Mode requires at least one', ...
                    ' active Point.\nINT16  Red Point  will fix', ...
                    ' by default.']), 'Error', 'modal'))
            pts_vec = [0, 1, 0, 0]';
            setpts(handles, pts_vec)
        end
        % Unfreeze disabled elements.
        freezel(handles, 'on')
        
    case 'optimal'
        set(handles.mode(1),'TooltipString', 'manual tuning the Properties');
        set(handles.mode(2),'TooltipString', 'magnetic tuning the Properties');
        if  sum(pts_vec) ~= 1
            uiwait(errordlg(sprintf(['Optimal Mode requires just single', ...
                    ' active Point.\nINT16  Red Point  will fix', ...
                    ' by default.']), 'Error', 'modal'))
            pts_vec = [0, 1, 0, 0]';
            setpts(handles, pts_vec)
        end
        % Set constraint of Signal Properties variety.
        [f_min, f_max] = deal(fo_min, 44100);   % Set Fs min, Fs max by default.
        set(handles.f_min,'String',num2str(f_min))
        set(handles.f_max,'String',num2str(f_max))
        num_bit = pow2(2+find(pts_vec));                % Get number of bits.
        sig_lens = 8*dat_len./[f_min, f_max]/num_bit;   % Get Tsig min, Tsig max.
        [sig_len_min, sig_len_max] = deal(sig_lens(2), sig_lens(1));
        set(handles.sig_len_min,'String',num2str(sig_len_min))
        set(handles.sig_len_max,'String',num2str(sig_len_max))
        % Freeze enabled elements.
        freezel(handles, 'of')
        matrix = get(handles.mode(3),'UserData');
        if  iscell(matrix)   &   matrix{1} == num_bit
            m = matrix{2};
            m = [m(:,2:end), m(:,1)];   % Roll the matrix.
        else
            % SORTING (quazi-optimization). Constraints are:
            %   - most possible Sampling Frequency is the most lower value
            %       amongst integers  8000, 8001, 8002, ..., 44099, 44100 Hz;
            %   - most possible Length of Signal (s) is near-integer number.
            f_ss = [f_max:-1:f_min];
            sig_lens = 8*dat_len/num_bit./f_ss; % Sorted possible Signal Lengths, s.
            % Recalculate the Properties.
            sig_lens = sortansw(sig_lens, 20, prec);    % Filtering by precision.
            f_ss = 8*dat_len/num_bit./sig_lens;
            m = [f_ss; sig_lens];
        end
        matrix = {num_bit, m};
        set(handles.mode(3),'UserData',matrix)
        set(handles.f_cur,'String',num2str(m(1,1)))
        set(handles.sig_len_cur,'String',num2str(m(2,1)))
        roundscreen(handles, pts_vec, m(2,1), m(1,1), dat_len, addr, prec);
        set(handles.mode(3),'TooltipString', ...
            sprintf('press  OPTIMAL\nto get new results'))
        return
end
% Read Values.
val_sig_len_cur = get(handles.slider_sig_len,'Value');
val_f_cur = get(handles.slider_f,'Value');
% Read Current State of Sampling Frequency, Hz.
[f_min, f_cur, f_max] = readvals(handles.f_min, handles.f_cur, handles.f_max);
% Make the values true and correct.
[f_min, f_new, f_max, val_f_new] = ...
    valscorr(f_min, f_cur, f_max, fo_min, fo_max, val_f_cur, addr);
if  val_f_cur ~= val_f_new  &  ~strcmp(addr, 'reset')
    addr = 'slider_f';                  % Simulate  slider_f  mode.
    f_cur = f_min + val_f_cur * (f_max - f_min);
end
set(handles.f_min,'String',num2str(f_min))
set(handles.f_max,'String',num2str(f_max))
% Read Current State of Signal Length, s.
[sig_len_min, sig_len_cur, sig_len_max] = ...
    readvals(handles.sig_len_min, handles.sig_len_cur, handles.sig_len_max);
[sig_len_min, sig_len_new, sig_len_max, val_sig_len_new] = ...
    valscorr(sig_len_min, sig_len_cur, sig_len_max, ...
    sig_leno_min, sig_leno_max, val_sig_len_cur, addr);
if  val_sig_len_cur ~= val_sig_len_new   &  ~strcmp(addr, 'reset')
    addr = 'slider_sig_len';        % Simulate  slider_sig_len  mode.
    sig_len_cur = sig_len_min + val_sig_len_cur * (sig_len_max - sig_len_min);
end
set(handles.sig_len_min,'String',num2str(sig_len_min))
set(handles.sig_len_max,'String',num2str(sig_len_max))
if  get(handles.fix,'Value')      % Are Sliders fixed proportionally each other?
    set(handles.exact,'Value',0)    % Reset a special (round down) Precision.
    if  strcmp(addr, 'slider_f')
        num_bito = 8*dat_len/sig_len_cur/f_cur;
        [sig_len_new, f_new, val_sig_len_new, val_f_new] = ...
            slidprop(sig_len_min, sig_len_new, sig_len_max, ...
            f_min, f_new, f_max, dat_len, num_bito);
    elseif strcmp(addr, 'slider_sig_len')
        num_bito = 8*dat_len/sig_len_cur/f_cur;     % Fix the last picture.
        [f_new, sig_len_new, val_f_new, val_sig_len_new] = ...
            slidprop(f_min, f_new, f_max, ...
            sig_len_min, sig_len_new, sig_len_max, dat_len, num_bito);
    end
end
% Check the Precision and Refresh values of  f_s  &  sig_len .
if  get(handles.exact,'Value')
    f_new = round(f_new);               % Set special Precision.
    sig_len_new = round(100*sig_len_new)/100;
    val_f = (f_new - f_min) / (f_max - f_min);
    val_sig_len = (sig_len_new - sig_len_min) / (sig_len_max - sig_len_min);
    set(handles.f_cur,      'String',sprintf(  '%d',f_new))
    set(handles.sig_len_cur,'String',sprintf('%.2f',sig_len_new))
    set(handles.slider_f,      'SliderStep',[1, 10]/(f_max-f_min))
    set(handles.slider_sig_len,'SliderStep', ...        % Change the Precision
            [0.01, 0.1]/(sig_len_max-sig_len_min))      % of  sig_len  Slider.
else                                    % Recover normal Precision.
    set(handles.f_cur,      'String',num2str(f_new))
    set(handles.sig_len_cur,'String',num2str(sig_len_new))
    set(handles.slider_f,      'SliderStep',[0.01, 0.1])
    set(handles.slider_sig_len,'SliderStep',[0.01, 0.1])
end
% Refresh the Sliders Values.
set(handles.slider_f,'Value',val_f_new)
set(handles.slider_sig_len,'Value',val_sig_len_new)
% Update Round Screen & update Increment Indicator.
rhos = roundscreen(handles, pts_vec, sig_len_new, f_new, dat_len, addr, prec);

% ============================================================
function valf = sortansw(vali, num, prec)
% SORTANSW  founds most possible value of  vali , where:
%   vali  is a vector of input values;
%   num   is a required number of vector elements of answer;
%   prec  is a required precision of answer;
%   valf  is a vector of founded values.
% Note:
%   1) valf  values are sorts based on number of digits after floating point;
%   2) higher  valf  values of uniform precision has more reliance.
v = round(vali/prec)*prec;      % Rounded values according to precision.
p = 10.^(0:-1:log10(prec));     % Vector of possible precisions of approximation.
V = v(ones(length(p),1),:);     % Repeat the  v  vector down the vertical.
P = p(ones(1,length(v)),:)';    % Repeat the  p  vector along the horizontal.
Vr = round(V./P).*P;            % Rounded matrix of values.
loc = (V == Vr);                % Find locations.
lof = find(loc(1,:));           % Founded locations of first row.
valf = v(lof(end:-1:1));        % Founded values, where
n = 1;                          %   much values sets to the end of the vector.
while length(lof) < num
    n = n + 1;
    lor = find(loc(n,:));
    lor(find(ismembc(lor, lof))) = [];  % Remove repeats elements of vector.
    lof = sort([lof, lor]);
    valf = [valf, v(lor(end:-1:1))];
end

% ============================================================
function rhos = roundscreen(handles, pts_vec, sig_len, f_s, dat_len, addr, prec)
% Get Current Signal Properties ( dat_len  was defined above).
num_bit = pow2(3:6);
% Read previous distances of Points.
xs = cell2mat(get(handles.pts,'Xdata'));
ys = cell2mat(get(handles.pts,'Ydata'));
rhos_prev = sqrt(xs.^2 + ys.^2);
% Main Formula.
f = inline('abs(1/8*sig_len*f_s*num_bit - dat_len)', ...
    'num_bit', 'sig_len', 'f_s', 'dat_len');
% 1) Get rhos & Points' sizes.
rhos = feval(f, num_bit, sig_len, f_s, dat_len);
rhoso = rhos'/15e4;                     % Scaling Points distance.
rhos = round(rhoso/prec)*prec;          % Rounding according to the precision.
sizes = round((7*rhos+3.5)./(rhos+.05));% Get sizes of Points.
border = .92;                           % Threshold of Points activity.
pts_of = find(~pts_vec | rhos > border);% Get indices of unactive Points.
rhos(pts_of) = border;                  % Make distant points small.
sizes(pts_of) = 5;                      % Make switched OFF points small.
pts_on = find(pts_vec & rhos < border); % Define switched ON & approached Points.
% 2) Get thetas (just switched ON & approached Points are intraprocess).
thetas = randint(4,1,360)*pi/180;   % If the 1st Running - define values of thetas.
if ~all([cell2mat(get(handles.pts,'Xdata')); cell2mat(get(handles.pts,'Ydata'))] == 0)
    thetas = atan2(ys, xs);     % Transform coordinates from Cartesian to polar.
end
% 3) Update the Round Screen.
hold on
for n = 1:4
    if  strcmp(addr, 'rotate_left')     % Rotate processing.
        thetas(n) = thetas(n) - 0.1;
    elseif strcmp(addr, 'rotate_right')
        thetas(n) = thetas(n) + 0.1;
    elseif any(n == pts_on)             % Freeze (lull) disabled Points.
        thetas(n) = thetas(n) + (rand(1)-.5)/5;     % Simulate Points' activity
    end                                 % (generates unsystematic movements).
    xs(n) = rhos(n)*cos(thetas(n));     % Transform coordinates to Cartesian.
    ys(n) = rhos(n)*sin(thetas(n));
    set(handles.pts(n), 'Xdata',xs(n), 'Ydata',ys(n), 'MarkerSize',sizes(n))
    set(handles.mks(n),'MarkerSize',sizes(n))       % Set size of current Point.
    if rhos(n) > 0.8 & abs(thetas(n)) < pi/2        % Prevent outside of the text.
        set(handles.txs(n),'HorizontalAlignment','right')
    else
        set(handles.txs(n),'HorizontalAlignment','left')
    end
    % Add the text annotation.
    set(handles.txs(n),'Position',[xs(n); ys(n) + 0.05])
end
hold off
% Set Scrn Colr:__/BLUE\_  ____/RED\____  ___/GREEN\___ & ___/CYAN\___.
colr_mat = [128, 128, 255; 255, 128, 128; 128, 255, 128; 128, 255, 255]/255;
cur_colr = sum(colr_mat .* repmat((sizes/10 - 1)/15, 1, 3));    % Own Formula.
pat_colr = [1, 1, 1] + cur_colr - max(cur_colr);
set(handles.pat,'FaceColor',pat_colr)               % Update Round Screen Color.
% Update Increment Indicator.
best_pt = pts_on(min(find(rhoso(pts_on) == min(rhoso(pts_on)))));
% Read previous distances of Points.
if length(best_pt)
    incr_vec = rhos - rhos_prev;
    best_pt_colr = get(handles.pts(best_pt),'Color');
else
    incr_vec = 0;
    best_pt_colr = [0.9 0.9 0.9];
end
if  incr_vec(best_pt) < -prec
    set(handles.indicator(3),'BackgroundColor',best_pt_colr)
    set(handles.indicator(2),'BackgroundColor','white')
    pause(0.05)
    set(handles.indicator(3),'BackgroundColor',[0.9 0.9 0.9])
elseif incr_vec(best_pt) > prec
    set(handles.indicator(1),'BackgroundColor',best_pt_colr)
    set(handles.indicator(2),'BackgroundColor','white')
    pause(0.05)
    set(handles.indicator(1),'BackgroundColor',[0.9 0.9 0.9])
end
set(handles.indicator(2),'BackgroundColor',best_pt_colr)
% Set Current Signal Properties Strings/TooltipStrings.
set(handles.text_sig_len_cur,'String',sprintf('Tsig = %.4f s' , sig_len))
set(handles.text_f_cur,      'String',sprintf(  'Fs = %.2f Hz', f_s    ))
set(handles.slider_sig_len,  'TooltipString',sprintf('%.4f s' , sig_len))
set(handles.slider_f,        'TooltipString',sprintf('%.2f Hz', f_s    ))
% Check  GET_STRING  Button.
get_condit = any(pts_vec==1 & ~rhos);
if  get_condit
    info_string = sprintf('\n\n\nInfo String\nis available');
    set(handles.info_string,'HorizontalAlignment','center')
    set(handles.getstring,'Enable','on')
    set(handles.listen,'Enable','on')
else
    info_string = sprintf('\n\n\nInfo String\nis not available');
    set(handles.info_string,'HorizontalAlignment','center')
    set(handles.getstring,'Enable','of')
    set(handles.listen,'Enable','of')
end
% Set  FRAME  of Signal Properties.
set(handles.info_string, 'String',info_string, ...
    'BackgroundColor',0.2*[get_condit,get_condit,get_condit]+0.7)
% Check  GET_STRING  Button.
if strcmp(addr, 'getinfo')
    num_pts = find(~rhos);
    info_string = var2str('', num_pts, sig_len, f_s, '');
    set(handles.info_string,'HorizontalAlignment','left')
    set(handles.save,'Enable','on')
else
    set(handles.save,'Enable','of')
end
% Check  SAVE  Button.
if strcmp(addr, 'save')
    str2inf(info_string, name_inf_full)
end


% ============================================================
%function


% ============================================================
function [val_new, valo_new, val_val, val_valo] = ...
    slidprop(val_min, val_new, val_max, ...
    valo_min, valo_new, valo_max, dat_len, num_bito);
val_newest = 8*dat_len/num_bito/valo_new;
val_val = (val_newest - val_min) / (val_max - val_min);
if val_val >= 0  &  val_val <= 1
    val_new = val_newest;
else
    if  val_val < 0
        val_val = 0;
        val_new = val_min;
    elseif val_val > 1
        val_val = 1;
        val_new = val_max;
    end
    valo_new = 8*dat_len/val_new/num_bito;
end
val_valo = (valo_new - valo_min) / (valo_max - valo_min);

% ============================================================
function info_string = var2str(name_dat, num_pts, sig_len, f_s, add_comms)
%                     *********
info_string = sprintf('= Info String defined ='); return
% Set String to be Saved.
% 1) Set  .DAT  Filename.
if ~isempty(name_dat)
    info_string = sprintf('Filename of Signal: ''%s''.', name_dat);
end
% 2) Set Data Type.
dat_types = {['int8 '; 'uint8'], 'int16', 'single', 'double'};
dat_type = dat_types{num_pts};
if num_bit == 8
    dat_type = questdlg('Which Data Type will sets?', ...
        'SIGVAR Question', 'int8','uint8','Cancel','int8');
    if isempty(dat_type) | strcmp(dat_type,'Cancel')
        dat_type = 'int8 or uint8';
    end
end
str_0 = sprintf('\n\nData Type: ''%s''.', deblank(dat_type));
info_string = [info_string, str_0];
% 3) Set Type of Signal (is unknown).
str_0 = sprintf('\n\nType of Signal:  UNKNOWN.');
info_string = [info_string, str_0];
% 4) Set Signal Properties string.
str_0 = sprintf('\n\nSignal Properties:\n');
info_string = [info_string, str_0];
str_s = repmat(' ', 1, 20);         % Sequence of Spaces to Design String Info.
% 5) Set Length of Signal, s.
str_0 = sprintf(['\n', str_s, 'sig_len = %d s;'], sig_len);
info_string = [info_string, str_0];
% 6) Set Sampling Frequency of Signal, Hz.
str_0 = sprintf(['\n', str_s, 'f_s = %d Hz.'], f_s);
info_string = [info_string, str_0];
% 7) Set Additional Commentaries of  .INF  File.
if ~length(add_comms)
    add_comms_str = ' are not determined.';
else
    add_comms_str = sprintf([':\n\n%s', add_comms]);
end
str_0 = sprintf(['\n\nCommentaries', add_comms_str]);
info_string = [info_string, str_0];
% End of  VAR2STR  SubFunction.

% ============================================================
function freezel(handles, state)
val = find(ismember({'of','on'},state(1:2)))-1;
% Freeze/Unfreese  GUIDE  elements.
set(handles.f_min,         'Enable',state)
set(handles.f_cur,         'Enable',state)
set(handles.f_max,         'Enable',state)
set(handles.sig_len_min,   'Enable',state)
set(handles.sig_len_cur,   'Enable',state)
set(handles.sig_len_max,   'Enable',state)
set(handles.slider_sig_len,'Enable',state)
set(handles.slider_f,      'Enable',state)
set(handles.reset,         'Enable',state)
set(handles.exact,         'Enable',state)
set(handles.rotate_left,   'Enable',state)
set(handles.rotate_right,  'Enable',state)
set(handles.life,          'Enable',state)
set(handles.fix,           'Enable',state)
set(handles.aim,           'Enable',state)
if ~val
    set(handles.fix,  'Value',~val) % ON  if not Manual Mode.
    set(handles.exact,'Value',val)  % OFF if not Manual Mode.
    set(handles.life, 'Value',val)  % OFF if not Manual Mode.
end
% End of  FREEZEL  SubFunction.

% ============================================================
function setpts(handles, pts_vec)
% Set state of required Points ON, others - OFF.
pts_on = find(pts_vec);
for n = 1:length(pts_on)
    set(handles.num_pts(pts_on(n)),'Value'  ,  1 )
    set(handles.pts(pts_on(n)),    'Visible','on')
    set(handles.txs(pts_on(n)),    'Visible','on')
end
pts_of = find(~pts_vec);
for n = 1:length(pts_of)
    set(handles.num_pts(pts_of(n)),'Value'  ,  0 )
    set(handles.pts(pts_of(n)),    'Visible','of')
    set(handles.txs(pts_of(n)),    'Visible','of')
end
% End of  SETPTS  SubFunction.

% ============================================================
function [val_min, val_cur, val_max] = ...
    readvals(hand_val_min, hand_val_cur, hand_val_max)
val_min = readhand(hand_val_min);
val_cur = readhand(hand_val_cur);
val_max = readhand(hand_val_max);
% End of  READVALS  SubFunction.

% ============================================================
function val = readhand(hand_val)
val_str = get(hand_val,'String');
val = abs(str2num(val_str));                % Just positive values reads.
if length(val) ~= 1
    val_str = strrep(val_str, ',', '.');    % Read value by replacing commas.
    if length(val) ~= 1
        val_str = strrep(val_str, ' ', ''); % Read value by replacing spaces.
    end
    val = abs(str2num(val_str));
end
% End of  READHAND  SubFunction.

% ============================================================
function [val_min, val_cur, val_max, val_val_new] = ...
    valscorr(val_min, val_cur, val_max, valo_min, valo_max, val_val_cur, addr)
if  strcmp(addr, 'reset')
    props = [1/7, 2/9];
    [val_min, val_max] = deal(valo_min, valo_max);
    [val_val_cur, val_val_new] = deal(props(double(val_min < 1000)+1));
    val_cur = val_min + val_val_cur * (val_max - val_min);
    return
end
% Read/Correct Current State of Edit blocks.
if  length(val_min)~=1  &  length(val_max)==1  &  length(val_cur)==1
    val_min = (val_cur - val_val_cur * val_max) / (1 - val_val_cur);
elseif length(val_min)==1  &  length(val_max)~=1  &  length(val_cur)==1
    val_max = (val_cur - val_min + val_val_cur * val_min) / val_val_cur;
elseif ~all([length(val_min), length(val_max), length(val_cur)]==1)
    [val_min, val_max] = deal(valo_min, valo_max);
    val_cur = val_min + val_val_cur * (val_max - val_min);
end
if  val_min < valo_min
    val_min = valo_min;
end
if  val_max > valo_max
    val_max = valo_max;
end
if  val_min > val_max
    [val_min, val_max] = deal(val_max, val_min);
elseif val_min == val_max
    [val_min, val_max] = deal(valo_min, valo_max);
end
if  val_cur < val_min  |  val_cur > val_max
    val_cur = val_min + val_val_cur * (val_max - val_min);
end
if  strncmp(addr, 'slider', 6)
    val_cur = val_min + val_val_cur * (val_max - val_min);
    val_val_new = val_val_cur;
else
    val_val_new = (val_cur - val_min) / (val_max - val_min);
end
% End of  VALSCORR  SubFunction.

% ============================================================
function str2inf(info_string, name_inf_full)
% Create .INF File.
fid = fopen(name_inf_full, 'w');            % Open .INF File for writing.
if fid < 0
    return                                  % Error File, No Error Comments.
end
fwrite(fid, info_string);                   % Save Info of Signal File.
fclose(fid);
% End of  STR2INF  SubFunction.

% ============================================================
% [EOF] HFSIM

% 777 Force-Majeure Cool&Happy Programming.   � Smirnoff, 2005.