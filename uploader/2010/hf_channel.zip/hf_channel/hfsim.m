function varargout = hfsim(varargin)
% HFSIM High-Frequency Channel Simulator.
%      HFSIM allows to get an easy access to data files processing
%      for the reason of High-Frequency Channel (3...30 MHz) Propagation
%      investigations.
%
%      It represents GUIDE-based High-Frequency (HF-) Channel Simulator,
%      which properties are sets according to Watterson model by ITU-R F.1487.
%
%      Called from MATLAB Command Window, HFSIM has no input/output arguments.
%      Inputs/Outputs must be represented by data files of  '.dat'  extension.
%      Supported data formats are either INT8, UINT8, INT16, SINGLE or DOUBLE.
%
%      Furthermore, HFSIM provides three drawings that are make visible
%      some processes inside HF-Channel.
%
% See also: HFCHANNEL, SIGGEN.

% Note: my English is poor  :)

% Last Modified by GUIDE v2.5 17-Jan-2005 07:77:35

% Begin initialization code (DO NOT EDIT!)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @hfsim_OpeningFcn, ...
                   'gui_OutputFcn',  @hfsim_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code (DO NOT EDIT!)

% --- Executes just before hfsim is made visible.
function hfsim_OpeningFcn(hObject, eventdata, handles, varargin)
% Set Current Directory.
cur_dir = [cd, filesep];                % Current Directory by Default.
ddname = 'My_Signals';                  % Default Directory Name (Short Format).
new_dir = [cur_dir, ddname, filesep];   % Get Default Current Directory Name.
all_files = dir(cur_dir);               % Get Full File Info.
all_names = {all_files.name};           % Get Available Files/Directories.
flag_dirs = [all_files.isdir];          % Directories Flags.
indcs_dir = find([flag_dirs]);          % Number of Available Directories.
% Check: Some Directory(-ies) Already Exists.
strt = find(ismember(lower(all_names), lower(ddname)));
if length(strt)
    dname = all_names{strt};
else                                    % Search a newest directory.
    all_dates = {all_files.date};
    for n = 1:sum(flag_dirs)            % Check of Available Directories.
        dname = all_names{n};
        if ~isvarname(dname)
            flag_dirs(n) = 0;
        end
    end
    indcs_dir = find([flag_dirs]);
    if length(indcs_dir)                % Search a newest directory.
        dir_dates = datenum(all_dates(indcs_dir));
        dname = all_names{indcs_dir(find(dir_dates==max(dir_dates)))};
    else
        dname = ddname;
    end
end
new_dir = [cur_dir, dname, filesep];
while ~exist(new_dir)
    [dname, fname, ename] = fileparts(new_dir(1:end-1));
    suc = mkdir(dname, fname);
    rmdir(new_dir)
    if ~suc
        new_dir = cur_dir;
        break                           % New Directory Creation was Bad Idea.
    end
    dlgTitle = ['HFSIM:  Current Directory Creation'];
    prompt = {'Create New Directory of Signals:'};
    inp_dir = char(inputdlg(prompt, dlgTitle, 1, {new_dir}));
    if ~length(inp_dir)                 % Window Canceled.
        new_dir = cur_dir;              % New Directory Creation was Rejected.
        break
    end
    if isdir(inp_dir)
        new_dir = inp_dir;              % Some True Directory Sets.
        break
    end
    [dummy, count] = find((inp_dir~=0) & ~((inp_dir=='/')|(inp_dir=='\')));
    inp_dir = inp_dir(:, 1:max(count));
    [dname, fname, ename] = fileparts(inp_dir);     % No Short Directory Format.
    if isdir(dname) & isvarname(fname) & ~length(ename)
        [suc, mes] = mkdir(dname, fname);
        if length(mes)
            disp(mes)
        end
        new_dir = inp_dir;              % Set new Current Directory.
    end
end
cur_dir = new_dir;
set(handles.val_directory,'String',cur_dir)
val_directory_Callback([], [], handles)
handles.output = hObject;   % Choose default command line output for HFSIM.
guidata(hObject, handles);  % Update handles structure.
% End of  hfsim_OpeningFcn  SubFunction.

% --- Outputs from this function are returned to the command line.
function varargout = hfsim_OutputFcn(hObject, eventdata, handles)
% Get default command line output from handles structure.
varargout{1} = handles.output;
checkprops(handles)         % Control configuration of HF Properties.
% End of  hfsim_OutputFcn  SubFunction.

% --- Executes during object creation, after setting all properties.
function val_namein_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on selection change in val_namein.
function val_namein_Callback(hObject, eventdata, handles)
setnames(handles)                  % Set Current File Comments.
% End of  val_namein_Callback  SubFunction.

% --- Executes during object creation, after setting all properties.
function val_directory_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on selection change in val_nameout.
function val_directory_Callback(hObject, eventdata, handles)
cur_dir = get(handles.val_directory,'String');  % Read Input Directory.
cur_dir(find((cur_dir=='/')|(cur_dir=='\'))) = filesep;
[dummy, count] = find([' ',cur_dir]==[cur_dir,' ']);
cur_dir(count(find(cur_dir(count)==filesep))) = [];
cur_dir = deblank(cur_dir);                     % Set User Commentaries String.
if cur_dir(end) ~= filesep
    cur_dir(end+1) = filesep;
end
if exist(cur_dir,'dir') == 7                    % New Current Directory Sets.
    set(handles.val_directory,'TooltipString',cur_dir)
    setnames(handles)                          % Control Names of .DAT Files.
else
    cur_dir = get(handles.val_directory,'TooltipString');
end
set(handles.val_directory,'String',cur_dir)     % Set 'dryclean' Directory Name.
% End of  val_directory_Callback  SubFunction.

% --- Executes on button press in button_setdir.
function button_setdir_Callback(hObject, eventdata, handles)
cur_dir = uigetdir(get(handles.val_directory,'TooltipString'));
if ischar(cur_dir)
    set(handles.val_directory,'TooltipString',[cur_dir,filesep])
    set(handles.val_directory,'String',[cur_dir,filesep])
    setnames(handles)
end
% End of  button_setdir_Callback  SubFunction.

% --- Executes on button press in button_listen.
function button_listen_Callback(hObject, eventdata, handles)
cur_dir = get(handles.val_directory,'String');  % Get Current Directory.
name_list = get(handles.val_namein,'String');
name_dat = deblank(name_list(get(handles.val_namein,'Value'),:));
name_dat_full = fullfile(cur_dir, name_dat);    % Get Full .DAT Filename.
[dat_typ, opencmd, loadcmd, descr] = finfo(name_dat_full);  %  .DAT  File Info.
dat_len = length(descr);                        % Length of  .DAT  File.
name_inf_full = strrep(name_dat_full,'.dat','.inf');% Get Full .INF Filename.
string_a = inf2str(name_inf_full);              % Get Actual  .INF  File.
string_b = get(handles.val_namein,'TooltipString');
[string_info, true_str]  = beststr(string_a, string_b, name_dat);
[shrt_vars, autodlg_flag] = str2var(string_info, dat_len);
if isempty(shrt_vars)           % Basic Signal Properties are Empty & Rejected.
    return
end
if autodlg_flag
    long_vars = str2var(string_info);           % Generate New String Info.
    string_info = var2str([long_vars, ' ', shrt_vars]);
    str2inf(string_info, name_inf_full)         % Create Missing  .INF  File.
    set(handles.val_namein,'TooltipString',string_info) % Update TooltipString.
else
    if true_str == 1            % Update Tooltip String.
        set(handles.val_namein,'TooltipString',string_info)
    elseif true_str == 2
        str2inf(string_info, name_inf_full) % Create Missing  .INF  File.
    end                         % Get Short String of Properties.
end                             % Get Short String of Properties.
eval(shrt_vars)                 % Carry Signal Properties to the Workspace.
% Check Sampling Frequency Value.
ai = analoginput('winsound');                   % Get PC Sound Card Capabilities.
f_s_range = deal(daqhwinfo(ai,{'MinSampleRate','MaxSampleRate'}));
if f_s < f_s_range{1}  |  f_s > f_s_range{2}
    errordlg([sprintf('Invalid Sampling Frequency value  f_s = %d Hz.\n', f_s), ...
              sprintf('Possible values are in the range [%d; ', f_s_range{1}), ...
              sprintf('%d] Hz.', f_s_range{2})], 'Error', 'modal')
    return
end
Sx = dat2sig(name_dat_full, dat_type);          % Load  .DAT  File.
set(handles.button_listen, 'String','Sound',  'Enable','of')
soundsc(Sx, f_s), pause(sig_len)                % Make a Sound.
set(handles.button_listen, 'String','Listen', 'Enable','on')
% End of  button_listen_Callback  SubFunction.

% ============================================================
function [string_info, true_str] = beststr(string_a, string_b, name_dat_orig)
% Choose the Best String that if most Suitable to  .DAT  File.
% It Checks: is One of Strings is Fully True String.
true_a = truestr(string_a, name_dat_orig);  % Set True Criteria of Info Strings.
true_b = truestr(string_b, name_dat_orig);
if true_a > true_b              % Make Decision:
    string_info = string_a;     %  string_a  is the most plausible,
    true_str = 1;               % set reliance to the first string argument.
elseif true_a < true_b
    string_info = string_b;     %  string_b  is the most plausible,
    true_str = 2;               % set reliance to the second string argument.
elseif true_a | true_b          % Both Strings are equal.
    string_info = string_a;     %  string_a  choosed by default,
    true_str = 0;               % set reliance between the string arguments.
else
    string_info = '';           % Both Strings are empty.
    true_str = [];
end
% End of  BESTSTR  SubFunction.

% ============================================================
function true_str = truestr(string_info, name_dat_orig)
%                  *********
% Read Full Context from the Info String.
long_vars = str2var(string_info);
% Execute Context String with MATLAB expression.
eval(long_vars)
% Set Solving Criteria (weight coefficients used).
exist_file = strcmp(name_dat_orig, name_dat);
true_str = exist_file*(length(find(add_comms=='='))/100 +  ...
    sum([~isempty(dat_type),~isempty(sig_len),~isempty(f_s)]) + 1/2);
% End of  TRUESTR  SubFunction.

% ============================================================
function [xxxx_vars, autodlg_flag] = str2var(varargin)
% Set Output Properties String.
autodlg_flag = 0;                    % This flag is ON if AutoDialog was used.
% 1) Check Input Arguments.
if nargin == 1
    string_info = varargin{1};
    mode = 'long';
elseif nargin == 2
    string_info = varargin{1};
    dat_len = varargin{2};
    mode = 'short';
else
    error('Invalid number of  STR2VAR  input arguments.')
end
% 2) Read Name of .DAT File.
pat = 'Filename\s+of\s+Signal:\s*''([\w\s]+.\w+)''\s*[.,;]\n*';
[strt, fnsh, tkns] = regexp(string_info, pat);
if length(strt) & prod(size([tkns{:}]))==2
    name_dat = string_info(tkns{:}(1):tkns{:}(2));
    name_dat = deblank(name_dat);
    isfilename = isfilnam(name_dat);
    if ~isfilename
        name_dat = '';
    end
    [fname, ename] = strtok(name_dat,'.');
    string_info(strt:fnsh) = [];                % Erase Full Filename String.
else
    name_dat = '';
end
name_dat_str = sprintf('name_dat = ''%s''; ', name_dat);
shrt_vars = name_dat_str;
% 3) Read Data Type (Precision of Signal).
pat = 'Data\s+Type:\s*''(\w+)''\s*[.,;]\n*';
[strt, fnsh, tkns] = regexp(string_info, pat);
if length(strt) & prod(size([tkns{:}]))==2
    dat_type = lower(string_info(tkns{:}(1):tkns{:}(2)));   %  Justification
    dat_types = {'int8','uint8','int16','single','double'}; %   dat_type value.
    if ~ismember(dat_types, dat_type)
        dat_type = '';
    end
    string_info(strt:fnsh) = [];                % Erase Data Type String.
else
    dat_type = '';
end
dat_type_str = sprintf('dat_type = ''%s''; ', dat_type);
shrt_vars = [shrt_vars, dat_type_str];
% 4) Read Length of Signal, s.
pat = '(sig_len\s*=\s*\d*[.,]*\d*)\s+s\s*[.,;]\n*';
[strt, fnsh, tkns] = regexp(string_info, pat);
if length(strt) & prod(size([tkns{:}]))==2      % Set  sig_len  Value, s.
    sig_len = string_info(tkns{:}(1):tkns{:}(2));
    indx_comma = find(sig_len==',');
    if indx_comma == 1
        sig_len(indx_comma) = '.';
    end
    sig_len_str = [sig_len, '; '];
    string_info(strt:fnsh) = [];                % Erase  sig_len  String.
else
    sig_len_str = 'sig_len = []; ';
end
shrt_vars = [shrt_vars, sig_len_str];
% 5) Read Sampling Frequency Value, Hz.
pat = '(f_s\s*=\s*\d*[.,]*\d*)\s+Hz\s*[.,;]\n*';
[strt, fnsh, tkns] = regexp(string_info, pat);
if length(strt) & prod(size([tkns{:}]))==2
    f_s = string_info(tkns{:}(1):tkns{:}(2));
    indx_comma = find(f_s==',');
    if indx_comma == 1
        f_s(indx_comma) = '.';
    end
    f_s_str = [f_s, '; '];
    string_info(strt:fnsh) = [];                % Erase  f_s  String.
else
    f_s_str = 'f_s = []; ';
end
shrt_vars = [shrt_vars, f_s_str];
% 6) Check the mode of  STR2VAR.
if strcmp(mode, 'long')
    long_vars = shrt_vars;
    % 7) Read Type of Signal.
    pat = 'Type\s+of\s+Signal:\s+(\w+-*\w*\s*[(\d)]*)\s*[.,;]\n*';
    [strt, fnsh, tkns] = regexp(string_info, pat);
    if length(strt) & prod(size([tkns{:}]))==2
        typ_sig = upper(string_info(tkns{:}(1):tkns{:}(2)));
        string_info(strt:fnsh) = [];            % Erase Type of Signal String.
    else
        typ_sig = '';
    end
    typ_sig_str = sprintf('typ_sig = ''%s''; ', typ_sig);
    long_vars = [long_vars, typ_sig_str];
    % 8) Read Additional Numerical Variables.
    pat = '\s+(\w+\s*=\s*\d*[.,]*\d*)\s+\w*[.,;]\n*';
    while 1
        [strt, fnsh, tkns] = regexp(string_info, pat);
        if ~length(tkns)
            break
        end
        any_var = string_info(tkns{1}(1):tkns{1}(2));
        indx_comma = find(any_var==',');
        if indx_comma == 1
            any_var(indx_comma) = '.';          % Replace comma to point.
        end
        any_var_str = [any_var, '; '];
        long_vars = [long_vars, any_var_str];
        string_info(strt(1):fnsh(1)) = [];      % Erase  any_var  String.
    end
    % 9) Erase Strings.
    pat = '\w+\s+Properties:';                  % String 'Sig/Chan Properties'.
    [strt, fnsh] = regexp(string_info, pat);
    string_info(strt:fnsh) = [];
    pat = 'Commentaries:';                      % Erase 'Commentaries' word.
    [strt, fnsh] = regexp(string_info, pat);
    string_info(strt:fnsh) = [];
    % 10) Cleaning Info String.
    indcs_del = find(int16(string_info)<32);    % Search Unvisible [\t\r\n\f]s.
    string_info(indcs_del) = ' ';               % Rub Out Unvisible [\t\r\n\f]s.
    indcs_spac = find(isspace(string_info));
    indcs_rept = find(diff([0,indcs_spac])==1); % Search Repetitious Blanks.
    indcs_del = indcs_spac(indcs_rept);
    string_info(indcs_del) = [];                % Erase Repetitious Blanks.
    % 11) Search Additional Info.
    if sum(isletter(string_info))
        add_comms = deblank(string_info);       % Set User Commentaries String.
        indcs_p = find(add_comms=='.' | add_comms==',' | add_comms==';');
        if ~isempty(indcs_p)
            new_p_str = [repmat(';',1,length(indcs_p)-1),'.'];
            add_comms(indcs_p) = deal(new_p_str);
        end
    else
        add_comms = '';
    end
    add_comms_str = sprintf('add_comms = ''%s'';', add_comms);
    % 12) Finish  STR2VAR  SubFunction.
    xxxx_vars = [long_vars, add_comms_str];
    return
end
%  SHORT  mode Continued.
add_comms = '';
eval(shrt_vars)
if isempty(dat_type) | isempty(sig_len) | isempty(f_s)
    [dat_type, sig_len, f_s, add_comms] = ...   % Run AutoDialog SubFunction.
        autodlg(dat_type, sig_len, f_s, dat_len, add_comms);
    autodlg_flag = 1;
    if isempty(dat_type) | isempty(sig_len) | isempty(f_s)
        xxxx_vars = '';                         % AutoDialog was Aborted.
        return
    else                                        % AutoDialog was Effective.
        dat_type_str  = sprintf('dat_type = ''%s''; ',  dat_type );
        sig_len_str   = sprintf( 'sig_len = %d; ',      sig_len  );
        f_s_str       = sprintf(     'f_s = %d; ',      f_s      );
    end
end
add_comms_str = sprintf('add_comms = ''%s''; ', add_comms);
xxxx_vars = [name_dat_str, dat_type_str, sig_len_str, f_s_str, add_comms_str];
% End of  STR2VAR  SubFunction.

% ============================================================
function isfilename = isfilnam(file_name)
file_name_fnd = '';
pat = '([\w\s]+.\w+)';
[strt, fnsh, tkns] = regexp(file_name, pat);
if length(strt) & prod(size([tkns{:}]))==2
    file_name_fnd = file_name(tkns{:}(1):tkns{:}(2));
end
isfilename = strcmp(file_name, file_name_fnd);
% End of  ISFILNAM  SubFunction.

% ============================================================
function [dat_type, sig_len, f_s, add_comms] = ...
                autodlg(dat_type_in, sig_len_in, f_s_in, dat_len, add_comms_in)
%              *********
% Happy Intelligence Control. Intelligence AutoDialog Window used.
isexist_dat_len = isnumeric(dat_len) & prod(size(dat_len))==1 & all(dat_len>0);
if ~isexist_dat_len                         % Check: is  dat_len  exist?
    error('dat_len  value must exist.')
end
add_comms = add_comms_in;
% Start AutoDialog Session.
while 1
    if  exist('true_token') ~= 1        % Primary Action (just single).
        % Intelligence Balancing/Correcting the answer.
        [dat_type, sig_len, f_s, true_token] = ...
                            autobal(dat_type_in, sig_len_in, f_s_in, dat_len);
        if  true_token == 1             % Signal Properties are full & balanced.
            break
        end
    end
    if  exist('true_token') == 1        % Secondary Action (reiterative).
        % 1) Dialog Window Datas Preparation.
        [prompt, dlgTitle, lineNo, def, add_comms] = ...
                            autotxt(dat_type, sig_len, f_s, add_comms, true_token);
        % 2) Set Dialog Window.
        answer = inputdlg(prompt, dlgTitle, lineNo, def);
        if ~length(answer)                      % Dialog was Aborted.
            [dat_type, sig_len, f_s] = deal(dat_type_in, sig_len_in, f_s_in);
            return                              %  Previous Properties recovering.
        end
        % 3) Read Dialog Window Inputs.
        [dat_type_ans, sig_len, f_s, add_comms] = deal(answer{:});
        sig_len_ans = str2num(sig_len);         % Read Input Numeric Values.
        f_s_ans = str2num(f_s);
        % 4) Intelligence Balancing/Correcting the answer.
        [dat_type, sig_len, f_s, true_token] = ...
                            autobal(dat_type_ans, sig_len_ans, f_s_ans, dat_len);
        % 5) Signal Properties Control.
        if  true_token == 1             % Signal Properties are full & balanced.
            if strcmp(dat_type_ans,dat_type) & sig_len_ans==sig_len & f_s_ans==f_s
                break                   % True Signal Properties was repeated.
            end
        end
    end
end
% End of  AUTODLG  SubFunction.

% ============================================================
function [prompt, dlgTitle, lineNo, def, add_comms] = ...
                        autotxt(dat_type, sig_len, f_s, add_comms, true_token)
% Prepare to AutoDialog Session.
% 1) Set  prompt.
prompt = {'','','',''};         % Standby  prompt  cell array.
str_check  = 'Check';
str_choose = 'Choose';
str_enter  = 'Enter';
str_dat_type = ' the Data Type';
str_sig_len  = ' the Length of Signal, s';
str_f_s      = ' the Sampling Frequency, Hz';
data_types_str = ':  INT8,  UINT8,  INT16,  SINGLE  or  DOUBLE';
% - set  dat_type  string:
if  true_token == 1
    prompt(1) = {[str_check, str_dat_type]};
elseif length(dat_type)
    prompt(1) = {[str_choose, str_dat_type]};
else
    prompt(1) = {[str_enter, str_dat_type, data_types_str]};
end
% - set  sig_len  string:
if  true_token == 1
    prompt(2) = {[str_check, str_sig_len]};         %  sig_len  is a Scalar.
elseif length(sig_len)
    prompt(2) = {[str_choose, str_sig_len]};        %  sig_len  is a Vector.
else
    prompt(2) = {[str_enter, str_sig_len]};         %  sig_len  is empty.
end
% - set  f_s  string:
if  true_token == 1
    prompt(3) = {[str_check, str_f_s]};
elseif length(f_s)
    prompt(3) = {[str_choose, str_f_s]};
else
    prompt(3) = {[str_enter, str_f_s]};
end
prompt(4) = {[str_enter, ' Your Commentaries']};
% 2) Set  dlgTitle.
if  true_token == 1
    dlgTitle = 'HFSIM:  Signal Properties are Full and Balanced';
elseif  true_token == 0
    dlgTitle = 'HFSIM:  Not Enough Signal Properties';
else
    dlgTitle = 'HFSIM:  Correct the Signal Properties';
end
% 3) Set  lineNo.
lineNo = [1 1 1 2]';
% 4) Set  def.
sig_len_str = num2str(sig_len);
f_s_str = num2str(f_s);
if length(add_comms)                    % Replace beginning/ending Blanks.
    indcs_comms = find(~isspace(add_comms));
    add_comms = add_comms(min(indcs_comms):max(indcs_comms));
end
def = {dat_type, sig_len_str, f_s_str, add_comms};
% End of  SETPROMPT  SubFunction.

% ============================================================
function [dat_type, sig_len, f_s, true_token] = ...
                                    autobal(dat_type, sig_len, f_s, dat_len)
%                                  *********
% Intelligence Signal Properties Automatic Control.
% Advanced Signal Properties Balancing ( dat_len  value is always known).
% 1) Supposition: Just single scalar Signal Property exists.
[dat_type, sig_len, f_s, true_token] = autofir(dat_type, sig_len, f_s, dat_len);
if  true_token == 1
    return                          % Signal Properties are true and balanced.
end
% 2) Supposition: Two of scalar Signal Properties exists.
[dat_type, sig_len, f_s, true_token] = autosec(dat_type, sig_len, f_s, dat_len);
if  true_token == 1
    return
end
% 3) Signal Properties are full. Control it.
[dat_type, sig_len, f_s, true_token] = autothi(dat_type, sig_len, f_s, dat_len);
% End of  AUTOBAL  SubFunction.

% ============================================================
function [dat_type, sig_len, f_s, true_token, num_bit] = ...
                                    autofir(dat_type, sig_len, f_s, dat_len)
%                                  *********
% Just Single Scalar Variable exist (AUTOBALMODE = 1).
% 1) Basic Constants.
f_s_min = 8000;                     % Lower Possible Sampling Frequency, Hz.
num_bits = pow2([3,3:6]);           % Possible Number of bits set.
% 2) Check the  AUTOBAL  mode.
[isscalars_vec, dat_type, num_bit, ind] = isscalars(dat_type, sig_len, f_s);
autobal_mode = int8(sum(int8(isscalars_vec)));
if  autobal_mode ~= 1
    true_token = int8([]);
    return
end
% 3) Bound-based Calculations.
%    Definitional domain of value/values is possible output.
if isscalars_vec(1)                 %  num_bit  value is scalar.
    sig_len_max = 8*dat_len/f_s_min./num_bit;
    sig_len_fix = fix(1e3*sig_len_max)/1e3;
    sig_len = sprintf('set %.3f s  or less', sig_len_fix);
    f_s = sprintf('set  %d Hz  or more', f_s_min);
    true_token = int8(0);
    return
elseif isscalars_vec(2)             %  sig_len  value is scalar.
    if isempty(num_bit)
        num_bit = num_bits;                 % Multiple Possible  num_bit  values.
    end
    f_s = 8*dat_len/sig_len./num_bit;
    indcs_true = find(f_s >= f_s_min);
    f_s = unique(f_s(indcs_true));          % Possible Sampling Frequencies, Hz.
    num_bit = unique(num_bit(indcs_true));
    if ~length(indcs_true)
        sig_len = [num2str(sig_len), ' s  is too much value'];
        true_token = int8(0);
        return
    end
elseif isscalars_vec(3)             %  f_s  value is scalar.
    sig_len = 8*dat_len*unique(1/f_s./num_bits);    % Possible Signal Lengths, s.
end
% 4) Data Type (Precision) Recovering, according to Number of Bits.
dat_type = bits2type(num_bit, ind);
% 5) Check the  AUTOBAL  mode.
isscalars_vec = isscalars(dat_type, sig_len, f_s);
autobal_mode = int8(sum(int8(isscalars_vec)));
if  autobal_mode == 3
    if  any(ind == [1,2])
        true_token = int8(1);
    else
        true_token = int8(0.5);
    end
else
    true_token = int8(0);
end
% End of  AUTOFIR  SubFunction.

% ============================================================
function [dat_type, sig_len, f_s, true_token, num_bit] = ...
                                    autosec(dat_type, sig_len, f_s, dat_len)
%                                  *********
% Two Scalar Variables exists (AUTOBALMODE = 2).
% 1) Check: is  AUTOBALMODE is suitable?
[isscalars_vec, dat_type, num_bit, ind] = isscalars(dat_type, sig_len, f_s);
autobal_mode = int8(sum(int8(isscalars_vec)));
if autobal_mode ~= 2
    true_token = int8([]);
    return
end
% 2) Basic Calculations.
if ~isscalars_vec(1)                    % num_bit
    num_bit = 8*dat_len/sig_len/f_s;
elseif ~isscalars_vec(2)                % sig_len
    sig_len = 8*dat_len/f_s/num_bit;
elseif ~isscalars_vec(3)                % f_s
    f_s = 8*dat_len/sig_len/num_bit;
end
% 3) Data Type (Precision) Recovering, according to Number of Bits.
dat_type = bits2type(num_bit, ind);
% 4) Token of true forming.
if  any(ind == [1,2])
    true_token = int8(1);
else
    true_token = int8(0.5);
end
% End of  AUTOSEC  SubFunction.

% ============================================================
function [dat_type, sig_len, f_s, true_token, num_bit] = ...
                                    autothi(dat_type, sig_len, f_s, dat_len)
%                                  *********
% Three Scalar Variables (full-vars-number) exist. Control the Properties.
% 1) Check: is  AUTOBALMODE is suitable?
[isscalars_vec, dat_type, num_bit, ind] = isscalars(dat_type, sig_len, f_s);
autobal_mode = int8(sum(int8(isscalars_vec)));
if  autobal_mode ~= 3
    true_token = int8([]);
    return
end
% 2) Basic Calculations.
num_bit_o = 8*dat_len/sig_len/f_s;
sig_len_o = 8*dat_len/f_s/num_bit;
f_s_o     = 8*dat_len/sig_len/num_bit;
if num_bit_o==num_bit  &  sig_len_o==sig_len  &  f_s_o==f_s
    % a) All Signal Properties are Full and Balanced.
    true_token = int8(1);
    return
else%... simulate the lack of properties.
    % It will determine on a course of action. Who can provide TRUE Properties?
    autofcn_types = {'autofir', 'autosec'};     % Possible  AUTOBAL  types.
    sig_prop = { dat_type, sig_len,  f_s };
    emp_prop = {    ''   ,    []  ,   [] };
    out_prop = repmat({'', [], [], [], []}', 1, 6);
    for autobal_mode = 2:-1:1
        autofcn_type = autofcn_types{autobal_mode};
        for n = 1:3             % By three variables: dat_type, sig_len, f_s.
            switch autofcn_type
                case 'autosec'          % Suppose two of Variables are True.
                    inp_prop    = sig_prop;
                    inp_prop(n) = emp_prop(n);  % Placing empty elements.
                case 'autofir'          % Suppose one of Variables is True.
                    inp_prop    = emp_prop;
                    inp_prop(n) = sig_prop(n);  % Subbing empty elements.
            end
            m = -3 * autobal_mode + 6 + n;      % Set Counter: 1, 2, ..., 6.
            out_prop(:,m) = autofcn(inp_prop, dat_len, autofcn_type);
        end
    end
    true_prop = findtrueprop(out_prop);         % Select the most true result.
end
[dat_type, sig_len, f_s, true_token, num_bit] = deal(true_prop{:});
% End of  AUTOTHI  SubFunction.

% ============================================================
function  true_prop = findtrueprop(all_prop)
% Read ALL_PROP cell array. Erase strings of  AUTODLG  Help.
true_tokens = [all_prop{4,:}];
[dummy, indcs_mostrue] = find(true_tokens==max(true_tokens));
true_token = true_tokens(indcs_mostrue);
% SubCases processing.
if  length(true_token) == 0
    true_prop = {'', [], [], [], []};       % No True Properties.
    return
elseif length(true_token) == 1
    true_prop = all_prop(:, indcs_mostrue);
    return
end
% Are there several variations of Signal Properties?
if  true_token(1) < 1
    true_prop = all_prop(:, indcs_mostrue(1));
    return
end
% Following actions processing disputable 'true' combinations of Properties.
sig_lens = [all_prop{2, indcs_mostrue}];
f_ss     = [all_prop{3, indcs_mostrue}];
prec_ind = 4;       % Indicator of precision (N of digits after floating point).
[sig_len, f_s, sig_lens, indx_true] = veclimit(sig_lens, f_ss, sig_lens, prec_ind);
% Most probable value of  indcs_mostrue  values.
indcs_mostrue = indcs_mostrue(indx_true);
true_prop = all_prop(:, indcs_mostrue);
% End of  FINDTRUEPROP  SubFunction.

% ============================================================
function varargout = veclimit(varargin)
% Find most probable value of several values. Limiting the vector of double
% values according to the number of digits after floating point of value.
if nargout ~= nargin
    error('The number of outputs should match the number of inputs.')
end
num_vecs = nargin - 1;
all_elements = [varargin{1:end-1}];
prec_ind = varargin{end};               % Number of digits after floating point
num_vals = length(all_elements)/num_vecs;   % (indicator of precision).
if  round(num_vals) ~= num_vals
    error('To VECLIMIT the number of elements of each vector must agree.')
end
all_vecs = vec2mat(all_elements, num_vals);
doubt_mat = zeros(num_vecs, num_vals);
% Count of digits after floating point.
for n = 1:num_vecs
    cur_vec = all_vecs(n,:);
    for m = 1:num_vals
        [dummy, tail_vec] = strtok(sprintf('%.16f', cur_vec(m)), '.');
        spac_vec = strrep(tail_vec(2:end), '0', ' ');
        doubt_mat(n,m) = length(deblank(spac_vec));
    end
end     % Set vector of doubtful columns...
doubt_vec = sum(doubt_mat);             % Set Flag of elements resemblance...
res_flag = all(doubt_vec>prec_ind*num_vecs) | all(doubt_vec<=prec_ind*num_vecs);
if res_flag                     % In this case cannot limiting the vector
    indx_true = [1:num_vals];   % of elements because each value is like another
else                            % in respectof current precision  prec_ind .
    [dummy, indx_true] = find(doubt_vec==min(doubt_vec));
end
new_vecs = all_vecs(:, indx_true);
varargout_mat = [new_vecs; indx_true]';
varargout = mat2cell(varargout_mat, size(varargout_mat,1), ...
    ones(1,size(varargout_mat,2)));
% End of  VECLIMIT  SubFunction.

% ============================================================
function out_prop = autofcn(inp_prop, dat_len, autofcn_type)
autofcn_types = {'autofir', 'autosec'};     % Possible types.
autofcn_type = lower(autofcn_type);
if length(find(ismember(autofcn_types, autofcn_type))) ~= 1
    error('No appropriate methods for subfunction AUTOFCN.')
end
[dat_type, sig_len, f_s, true_token, num_bit] = ...
    eval([autofcn_type, '(inp_prop{1}, inp_prop{2}, inp_prop{3}, dat_len)']);
out_prop = {dat_type, sig_len, f_s, true_token, num_bit};
% End of  AUTOFCN  SubFunction.

% ============================================================
function [isscalars_vec, dat_type, num_bit, ind] = ...
                                    isscalars(dat_type, sig_len, f_s)
% Check the  AUTOBAL  mode.        ***********
% Number of Bits Recovering, according to Data Type (Precision).
[num_bit, ind] = type2bits(dat_type);
% Set ISSCALARS logical vector.
isscalar_num_bit = prod(size(num_bit))==1;
isscalar_sig_len = isnumeric(sig_len) & prod(size(sig_len))==1 & all(sig_len>0);
isscalar_f_s = isnumeric(f_s) & prod(size(f_s))==1 & all(f_s>0);
isscalars_vec = [isscalar_num_bit, isscalar_sig_len, isscalar_f_s];
if nargout == 1
    return
end
error_str = 'unknown Data Type format';
if length(dat_type)  &  ~length(num_bit)
    if strcmp(error_str, dat_type)
        dat_type = '';
    else
        dat_type = error_str;
    end
end
% End of  ISSCALARS  SubFunction.

% ============================================================
function [num_bit, ind, dat_type_cell] = type2bits(dat_type_str)
%                                       ***********
% Check Data Type String  &  Search number of bits.
num_bit = [];
ind = 0;
dat_type_cell = {''};
if ischar(dat_type_str)
    if ~length(dat_type_str)
        return
    end
else
    error('Requires string input.')
end
% Main constants.
dat_types = {'int8', 'uint8', 'int16', 'single', 'double'};
num_bits = pow2([3,3:6]);
% Replace beginning/ending Blanks.
indcs_dat_type = find(~isspace(dat_type_str));
dat_type_str = dat_type_str(min(indcs_dat_type):max(indcs_dat_type));
% Read  dat_type  Context.
indcs_true = [];
if length(dat_type_str)
    dat_type_fnd = [' ', lower(dat_type_str), ' '];
    pat = ['\s+(int8|uint8|int16|single|double)[,;|]*\s+'];
    n = 1;
    while 1
        [strt, fnsh, tkns] = regexp(dat_type_fnd, pat);
        if ~length([tkns{:}])
            break
        end
        indcs_fnd = [tkns{1}(1):tkns{1}(2)];
        dat_type_n = dat_type_fnd(indcs_fnd);
        dat_type_cell(n) = {dat_type_n};
        dat_type_fnd(indcs_fnd) = [];
        indcs_true(n) = find(ismember(dat_types,dat_type_n));
        n = n + 1;
    end
    [num_bit, count] = sort(num_bits(indcs_true));
    dat_type_cell = dat_type_cell(count);
    indcs_8 = find(num_bit==8);
    flags_8 = ismember(dat_types, dat_type_cell(indcs_8));
    ind = bi2de(double(flags_8(1:2)));
    num_bit = unique(num_bit);
end
% End of  TYPE2BITS  SubFunction.

% ============================================================
function [dat_type_str, dat_type_cell] = bits2type(varargin)
%                                       ***********
% 1) Check input arguments adequacy.
if nargin == 1
    num_bit = varargin{:};
    ind = [];
elseif nargin == 2
    num_bit = varargin{1};
    ind = varargin{2};
else
    error('Too many input arguments.')
end
dat_type_str = '';
dat_type_cell = cell('');
if isnumeric(num_bit)
    if ~length(num_bit)
        return
    end
else
    error('Requires numeric input.')
end
if ~isnumeric(ind)  |  prod(size(ind)) > 1
    error('Invalid IND value. Must be numeric scalar.')
end
if length(ind) & all(ind~=[0:3])
    error('Invalid IND value. Must be either 0, 1, 2 or 3.')
end
% 2) Main constants.
num_bits = pow2([3,3:6]);
flags_num_bit = ismember(num_bits, num_bit);
if ~any(flags_num_bit)
    return                      % Unknown Data Type format.
end
dat_types = {'int8', 'uint8', 'int16', 'single', 'double'};
% 3) Read  num_bit  Context.
if length(ind)
    flags_ind = ind==[2, 1, 7, 7, 7];
else
    flags_ind = zeros(1, 5);
end
ind_flags = xor(flags_num_bit, flags_ind);
indcs_true = find(ind_flags);
if length(indcs_true) == 1
    dat_type_str = dat_types{indcs_true};
    dat_type_cell = dat_types(indcs_true);
elseif length(indcs_true)
    dat_type_cell = dat_types(indcs_true);
    dat_type_a = [char(dat_type_cell), repmat('  ',length(dat_type_cell),1)];
    dat_type_b = reshape(dat_type_a',1,[]);
    % Delete undouble spaces.
    indcs_spc = find(isspace(dat_type_b));
    indcs_diff = find(isspace(['  ',dat_type_b(1:end-2)]));
    indcs_del = find(indcs_spc==indcs_diff);
    dat_type_b(indcs_spc(indcs_del)) = [];
    % Delete completing spaces.
    dat_type_str = dat_type_b(1:end-2);
end
% End of  BITS2TYPE  SubFunction.

% ============================================================
function string_info = var2str(long_vars)
%                     *********
string_info = '';
if isempty(long_vars)
    return
end
eval(long_vars)
% Set String to be Saved.
% 1) Set  .DAT  Filename.
if exist('name_dat') == 1
    if ~isempty(name_dat)
        string_info = sprintf('Filename of Signal: ''%s''.', name_dat);
    end
else
    return                      %  .DAT  Filename is a Binding variable.
end
% 2) Set Data Type.
if exist('dat_type') == 1
    if ~isempty(dat_type)
        str_0 = sprintf('\n\nData Type: ''%s''.', dat_type);
        string_info = [string_info, str_0];
    end
end
% 3) Set Type of Signal.
if exist('typ_sig') == 1
    if isempty(typ_sig)
        typ_sig = 'unknown';
    end
    str_0 = sprintf('\n\nType of Signal:  %s.', upper(typ_sig));
    string_info = [string_info, str_0];
end
% Check: are any variables of Signal Properties exist?
if any([exist('sig_len'), exist('f_c'), exist('f_s'), exist('f_min'), ...
            exist('f_max')]==1)
    str_0 = sprintf('\n\nSignal Properties:\n');
    string_info = [string_info, str_0];
    str_s = repmat(' ', 1, 20);     % Sequence of Spaces to Design String Info.
end
% 4) Set Length of Signal, s.
if exist('sig_len') == 1
    if ~isempty(sig_len)
        str_0 = sprintf(['\n', str_s, 'sig_len = %d s;'], sig_len);
        string_info = [string_info, str_0];
    end
end
% 5) Set Lower Signal Frequency, Hz.
if exist('f_min') == 1
    if ~isempty(f_min)
        str_0 = sprintf(['\n', str_s, 'f_min = %d Hz;'], f_min);
        string_info = [string_info, str_0];
    end
end
% 6) Set Higher Signal Frequency, Hz.
if exist('f_max') == 1
    if ~isempty(f_max)
        str_0 = sprintf(['\n', str_s, 'f_max = %d Hz;'], f_max);
        string_info = [string_info, str_0];
    end
end
% 7) Set Current Signal Frequency, Hz.
if exist('f_c') == 1
    if ~isempty(f_c)
        str_0 = sprintf(['\n', str_s, 'f_c = %d Hz;'], f_c);
        string_info = [string_info, str_0];
    end
end
% 8) Set Sampling Frequency of Signal, Hz.
if exist('f_s') == 1
    if ~isempty(f_s)
        str_0 = sprintf(['\n', str_s, 'f_s = %d Hz.'], f_s);
        string_info = [string_info, str_0];
    end
end
% 9) Set Additional Commentaries of  .INF  File.
if exist('add_comms') == 1
    if ~length(add_comms)
        add_comms_str = ' are not determined.';
    else
        add_comms_str = sprintf([':\n\n%s', add_comms]);
    end
    str_0 = sprintf(['\n\nCommentaries', add_comms_str]);
    string_info = [string_info, str_0];
end
% End of  VAR2STR  SubFunction.

% ============================================================
function str2inf(string_info, name_inf_full)
% Create .INF File.
fid = fopen(name_inf_full, 'w');            % Open .INF File for writing.
if fid < 0
    return                                  % Error File, No Error Comments.
end
fwrite(fid, string_info);                   % Save Info of Signal File.
fclose(fid);
% End of  STR2INF  SubFunction.

% --- Executes on button press in button_delete.
function button_delete_Callback(hObject, eventdata, handles)
cur_dir = get(handles.val_directory,'String');
name_list = get(handles.val_namein, 'String');          % Get .DAT files.
name_dat = deblank(name_list(get(handles.val_namein,'Value'),:));
name_dat_full = [cur_dir,name_dat];
button_name = questdlg( ...
    sprintf('Do you really want to delete the selected file ''%s''?', name_dat));
if strcmp(button_name,'Yes')
    delete(name_dat_full)                   % Delete .DAT file.
    name_inf_full = strrep(name_dat_full,'.dat','.inf'); % Get '.INF' Filename.
    if exist(name_inf_full) == 2            % If .INF File exists.
        delete(name_inf_full)               % Delete .INF file.
    end
end
setnames(handles)                          % Refresh File List.
% End of  button_delete_Callback  SubFunction.

% --- Executes during object creation, after setting all properties.
function val_typehf_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on selection change in val_typehf.
function val_typehf_Callback(hObject, eventdata, handles)
checkprops(handles)
% End of  val_typehf_Callback  SubFunction.

% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on selection change in val_numwav.
function popupmenu2_Callback(hObject, eventdata, handles)
checkprops(handles)
% End of  popupmenu2_Callback  SubFunction.

% --- Executes during object creation, after setting all properties.
function val_timdel_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on selection change in val_timdel.
function val_timdel_Callback(hObject, eventdata, handles)
checkprops(handles)
% End of  val_timdel_Callback  SubFunction.

% --- Executes on button press in set_fadrat.
function set_fadrat_Callback(hObject, eventdata, handles)
set(handles.set_dopspr,'Value',~get(hObject,'Value'))
checkprops(handles)
% End of  set_fadrat_Callback  SubFunction.

% --- Executes during object creation, after setting all properties.
function val_fadrat_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on selection change in val_fadrat.
function val_fadrat_Callback(hObject, eventdata, handles)
checkprops(handles)
% End of  val_fadrat_Callback  SubFunction.

% --- Executes on button press in set_dopspr.
function set_dopspr_Callback(hObject, eventdata, handles)
set(handles.set_fadrat,'Value',~get(hObject,'Value'))
checkprops(handles)
% End of  set_dopspr_Callback  SubFunction.

% --- Executes during object creation, after setting all properties.
function val_dopspr_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on selection change in val_dopspr.
function val_dopspr_Callback(hObject, eventdata, handles)
checkprops(handles)
% End of  val_dopspr_Callback  SubFunction.

% --- Executes on button press in set_growav.
function set_growav_Callback(hObject, eventdata, handles)
checkprops(handles)
% End of  set_growav_Callback  SubFunction.

% --- Executes during object creation, after setting all properties.
function val_growav_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on selection change in val_growav.
function val_growav_Callback(hObject, eventdata, handles)
% End of  val_growav_Callback  SubFunction.

% --- Executes on button press in set_dopsh.
function set_dopsh_Callback(hObject, eventdata, handles)
checkprops(handles)
% End of  set_dopsh_Callback  SubFunction.

% --- Executes during object creation, after setting all properties.
function val_dopsh_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on selection change in val_growav.
function val_dopsh_Callback(hObject, eventdata, handles)
% End of  val_dopsh_Callback  SubFunction.

% --- Executes on button press in set_snr.
function set_snr_Callback(hObject, eventdata, handles)
checkprops(handles)
% End of  set_snr_Callback  SubFunction.

% --- Executes during object creation, after setting all properties.
function val_snr_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on selection change in val_snr.
function val_snr_Callback(hObject, eventdata, handles)
checkprops(handles)
% End of  val_snr_Callback  SubFunction.

% --- Executes during object creation, after setting all properties.
function val_nameout_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on selection change in val_nameout.
function val_nameout_Callback(hObject, eventdata, handles)
% End of  val_nameout_Callback  SubFunction.

% --- Executes on button press in button_starthf.
function button_starthf_Callback(hObject, eventdata, handles)
input_vars = prop2hf(handles);
if isempty(input_vars)
    return
end
hfchannel(input_vars{:});               % Run  HFCHANNEL.
checkprops(handles)      % ************* Is need the string? ************
% End of  button_starthf_Callback  SubFunction.

% --- Manual Subfunctions (MSFs).
% ============================================================
function hfsim_action(src, evnt, dummy)
beep, pause(0)
% Some KEY was pressed.
% End of  HFSIM_ACTION  SubFunction.

% ============================================================
function string_info = inf2str(name_inf_full)
string_info = '';
fid = fopen(name_inf_full);             % Open .INF File for reading.
if fid < 0                              % .INF File does not exist.
    return
end
string_int = fread(fid);                % Read Info about Current File.
fclose(fid);
string_info = char(string_int');        % Convert to String Format.
% End of  INF2STR  SubFunction.

% ============================================================
function setnames(handles)
cur_dir = get(handles.val_directory,'TooltipString');
dat_files = dir([cur_dir,'*.dat']);
dat_names_cell = {dat_files.name};      % Get List of '.DAT' Files.
% Control the Number of Files in Current Directory.
num_files = length(dat_names_cell);
file_pos = get(handles.val_namein,'Value');
if ~num_files
    set(handles.val_namein,'Value',[])
    set(handles.val_namein,'TooltipString', ...
        'No files found in Current Directory')
    set(handles.button_starthf,'Enable','of')   % Switch off START HF Button.
    set(handles.button_listen, 'Enable','of')   % Switch off LISTEN  Button.
    set(handles.button_delete, 'Enable','of')   % Switch off DELETE  Button.
else
    if ~length(file_pos)
        file_pos = 1;
    elseif file_pos > num_files
        file_pos = num_files;
    end
    set(handles.val_namein,'Value',file_pos)    % Indicate the File of Listing.
    name_dat = dat_names_cell{file_pos};        % .DAT Filename (Short Format).
    name_inf = strrep(name_dat, '.dat', '.inf');% .INF Filename (Short Format).
    name_inf_full = [cur_dir, name_inf];        % .INF Filename (Long Format).
    string_a = inf2str(name_inf_full);          % Read .INF File.
    string_b = get(handles.val_namein,'TooltipString'); % Get TooltipString Info.
    [string_info, true_str] = beststr(string_a, string_b, name_dat); % Choose the Best String.
    if true_str == 1
        set(handles.val_namein,'TooltipString',string_info)
    elseif true_str == 2
        str2inf(string_info, name_inf_full)     % Recover Losted .INF File.
    end
    if isempty(string_info)     % .INF File does not exist or much corrupted.
        name_dat_str = sprintf('name_dat = ''%s''; ', name_dat);
        string_info = var2str(name_dat_str);
        set(handles.val_namein,'TooltipString',string_info)
    end
    set(handles.button_starthf,'Enable','on')   % Switch on START HF Button.
    set(handles.button_listen, 'Enable','on')   % Switch on  LISTEN  Button.
    set(handles.button_delete, 'Enable','on')   % Switch on  DELETE  Button.
end
set(handles.val_namein,'String',char(dat_names_cell))
% End of  SETNAMES  SubFunction.

% ============================================================
function string_info = win2str(handles)
% Get Current Directory.
cur_dir = get(handles.val_directory,'TooltipString');
% Get Current .DAT Filename.
dat_names_cell = {get(handles.val_namein,'String')};    % Get List of .DAT Files.
file_pos = get(handles.val_namein,'Value'); % Get Position of Current Filename.
name_dat = dat_names_cell{file_pos};                % Short .DAT Format.
name_dat_full = fullfile(cur_dir, name_dat);        % Long .DAT Format.
% Get  .DAT  File Info.
[dat_typ, opencmd, loadcmd, descr] = finfo(name_dat_full);
dat_len = length(descr);                            % Length of  .DAT  File.
% Get Current .INF Filename.
name_inf_full = strrep(name_dat_full,'.dat','.inf');% Long .INF Format.
% Get String Info from Current .INF File.
string_info = inf2str(name_inf_full);               % String Reader.
string_info = get(handles.val_namein,'TooltipString');
[shrt_vars, autodlg_flag] = str2var(string_info, dat_len);
if isempty(shrt_vars)
    return
end
eval(shrt_vars)
empty_flag = isempty(dat_type)|isempty(sig_len)|isempty(f_s);
[dat_type, sig_len, f_s, ur_comms] = ...
        var2var(dat_len, dat_type, sig_len, f_s, add_comms)
if length(string_info)          % Read .INF Filename from TooltipString.
    
    if ~strcmp(name_dat, name_dat_existed)
        string_info = sprintf('Filename of Signal: ''%s''.', name_dat);
    end
else
    string_info = sprintf('Filename of Signal: ''%s''.', name_dat);
end

% ============================================================
function checkprops(handles)
fadrat2dopspr(handles,get(handles.set_fadrat,'Value'))
%  snr_val  Value Control.
snr_val_str = get(handles.val_snr,'String');
if prod(size(str2num(snr_val_str)))
    set(handles.val_snr,'UserData',snr_val_str);
end
if get(handles.set_snr,'Value')
    snr_val_str = get(handles.val_snr,'UserData');
    state = 'on';
else
    snr_val_str = '100';
    state = 'off';
end
set(handles.val_snr, 'Enable',state, 'String',snr_val_str)
set(handles.text_dB, 'Enable',state)
% Check ITU-R Properties.
type_hf_pointer = get(handles.val_typehf,'Value');
if type_hf_pointer < 4
    setituprops(handles, type_hf_pointer)
    set(handles.val_typehf,'UserData',1);
    return
end
% If after ITU-R HF Channel.
if get(handles.val_typehf,'UserData')
    hfenabler(handles, 'on')                   % Get % Set Default Properties.
    tim_del_str = get(handles.val_timdel,'String');
    set(handles.val_timdel,'UserData',tim_del_str)
    dop_sprd_str = get(handles.val_dopspr,'String');
    set(handles.val_dopspr,'UserData',dop_sprd_str)
    set(handles.val_typehf,'UserData',0)        % Set hf_histr to ZERO.
    return
end
%  tim_del  Value Control.
tim_del_str = get(handles.val_timdel,'String'); % Actual Time Delay, ms.
if prod(size(str2num(tim_del_str)))==1  &  str2num(tim_del_str)>0
    set(handles.val_timdel,'UserData',tim_del_str)
else                                    % Get & Set Latest True Time Delay, ms.
    tim_del_str = get(handles.val_timdel,'UserData');
    set(handles.val_timdel,'String',tim_del_str)
end
% Checkboxes Control.
states = {'off', 'on'};             % Possible states of Checkboxes (to Enable).
state_vec = [states(get(handles.set_fadrat,'Value')+1), ...
    states(get(handles.set_dopspr,'Value')+1), ...
    states(get(handles.set_growav,'Value')+1), ...
    states(get(handles.set_dopsh,'Value')+1)];
%  fad_rate  Value Control.
set(handles.val_fadrat,'Enable',state_vec{1})
set(handles.text_fpm,  'Enable',state_vec{1})
fad_rate_str = get(handles.val_fadrat,'String'); % Actual Fading Rate, fpm.
if prod(size(str2num(fad_rate_str)))==1  &  str2num(fad_rate_str)>0
    set(handles.val_fadrat,'UserData',fad_rate_str)
else                                % Get & Set The Latest True Time Delay, ms.
    fad_rate_str = get(handles.val_fadrat,'UserData');
    set(handles.val_fadrat,'String',fad_rate_str)
end
%  dop_sprd  Value Control.
set(handles.val_dopspr,'Enable',state_vec{2})
set(handles.text_Hz1,  'Enable',state_vec{2})
dop_sprd_str = get(handles.val_dopspr,'String'); % Actual Doppler Spread, Hz.
if prod(size(str2num(dop_sprd_str)))==1  &  str2num(dop_sprd_str)>0
    set(handles.val_dopspr,'UserData',dop_sprd_str)
else                                % Get & Set Latest True Doppler Spread, Hz.
    dop_sprd_str = get(handles.val_dopspr,'UserData');
    set(handles.val_dopspr,'String',dop_sprd_str)
end
%  gro_part  Value Control.
gro_part = get(handles.val_growav,'String');
if prod(size(str2num(gro_part)))==1  &  ...
        str2num(gro_part)>=0  &  str2num(gro_part)<=100
    set(handles.val_growav,'UserData',gro_part);
end
if strcmp(state_vec{3},'on')
    gro_part = get(handles.val_growav,'UserData');
else
    gro_part = '0';
end
set(handles.val_growav,'Enable',state_vec{3}, 'String',gro_part)
set(handles.text_perc, 'Enable',state_vec{3})
%  dop_shft  Value Control.
dop_shft = get(handles.val_dopsh,'String');
if prod(size(str2num(dop_shft)))==1  &  str2num(dop_shft)>=0
    set(handles.val_dopsh,'UserData',dop_shft);     % If dop_shft Checkbox Switched.
end
if strcmp(state_vec{4},'on')
    dop_shft = get(handles.val_dopsh,'UserData');
else
    dop_shft = '0';
end
set(handles.val_dopsh, 'Enable',state_vec{4}, 'String',dop_shft)
set(handles.text_Hz2,  'Enable',state_vec{4})
return
% Single Path Channel Processing (tim_del  Value Control).
num_wavs = get(handles.val_numwav,'Value');
tim_del = get(handles.val_timdel, 'String');
if num_wavs == 1 & get(handles.val_growav,'String') == '0'
    if strcmp(get(handles.val_timdel,'Enable'), 'on')
        set(handles.val_timdel,'UserData',tim_del)
    end
    set(handles.val_timdel, 'Enable','of', 'String','0')
    set(handles.text_timdel,'Enable','of')
    set(handles.text_ms,    'Enable','of')
else
    set(handles.val_timdel, 'Enable','on', 'String',tim_del)
    set(handles.text_timdel,'Enable','on')
    set(handles.text_ms,    'Enable','on')
end
% End of  checkprops  SubFunction.

% ============================================================
function hfenabler(handles, state)
val = strcmp(state, 'on');
set(handles.text_numwav,'Enable',state)
set(handles.val_numwav, 'Enable',state)
set(handles.text_timdel,'Enable',state)
set(handles.val_timdel, 'Enable',state)
set(handles.text_ms,    'Enable',state)
set(handles.set_dopspr, 'Enable',state)
set(handles.val_dopspr, 'Enable',state)
set(handles.text_Hz1,   'Enable',state)
set(handles.set_fadrat, 'Enable',state)
set(handles.set_growav, 'Enable',state)
set(handles.set_dopsh,  'Enable',state)
if val
    return
end
set(handles.set_dopspr, 'Value', 0)
set(handles.set_fadrat, 'Value', 0)
set(handles.set_growav, 'Value', 0)
set(handles.set_dopsh,  'Value', 0)
set(handles.val_fadrat, 'Enable',state)
set(handles.text_fpm,   'Enable',state)
set(handles.val_growav, 'Enable',state)
set(handles.text_perc,  'Enable',state)
set(handles.val_dopsh,  'Enable',state)
set(handles.text_Hz2,   'Enable',state)
% End of  HFENABLER  SubFunction.

% ============================================================
function setituprops(handles, type_hf_pointer)
% Set ITU-R F.1487 HF Channel Properties.
num_wavs = 2;               % Two-wave HF Channel Model.
types_hf = {'Good', 'Moderate', 'Poor'};  % Available States of ITU HF Channel.
type_hf = types_hf{type_hf_pointer};
switch type_hf
    case 'Good'             % Type of HF Channel: GOOD.
        tim_del  = 0.5;     % Time Delay, ms.
        dop_sprd = 0.1;     % Doppler Spread, Hz.
    case 'Moderate'
        tim_del  = 1.0;
        dop_sprd = 0.5;
    case 'Poor'
        tim_del  = 2.0;
        dop_sprd = 1.5;
end
gro_part = 0;               % Ground wave part is absent.
dop_shft = 0;               % Doppler Shift is absent.
% Dialog Window State Control (SNR is out of Control).
hfenabler(handles, 'of')
set(handles.val_numwav,'Value', num_wavs)   % - set number of waves
set(handles.val_timdel,'String',num2str(tim_del))  % - set differencial time delay
set(handles.set_fadrat,'Value',0)           % - set fading rate
set(handles.set_dopspr,'Value',1)           % - set Doppler spread
set(handles.val_dopspr,'String',num2str(dop_sprd))
fadrat2dopspr(handles,0)                % Recalculate & Set Fading Rate Value.
set(handles.val_growav,'String',num2str(gro_part))  % - set groundwave part
set(handles.val_dopsh, 'String',num2str(dop_shft))  % - set Doppler shift
% End of SETITUPROPS SubFunction.

% ============================================================
function fadrat2dopspr(handles, reverse_flag)
% Convert Fading Rate (fpm) to Doppler Spread (Hz). Can be forward or reverse.
if reverse_flag == 1                    % Convert Fading Rate to Doppler Spread.
    fadrat = str2num(get(handles.val_fadrat,'String'));
    dopspr = round(100*1.356/60*fadrat)/100;        % Rounding result to 1e-2.
    set(handles.val_fadrat,'String',num2str(fadrat))
    set(handles.val_dopspr,'String',num2str(dopspr))
elseif reverse_flag == 0                % Convert Doppler Spread to Fading Rate.
    dopspr = str2num(get(handles.val_dopspr,'String'));
    fadrat = round(100*60/1.356*dopspr)/100;
    set(handles.val_fadrat,'String',num2str(fadrat))
    set(handles.val_dopspr,'String',num2str(dopspr))
else
    error('Invalid  reverse_flag  value. Must be equal to 0 or 1.')
end
% End of FADRAT2DOPSPR SubFunction.

% ============================================================
function input_vars = prop2hf(handles)
% Forming the Vector of  HFCHANNEL  Inputs.
input_vars = [];
% Get Signal Properties.
cur_dir = get(handles.val_directory,'TooltipString');
names_dat = get(handles.val_namein,'String');
name_dat = deblank(names_dat(get(handles.val_namein,'Value'),:));
name_dat_full = fullfile(cur_dir, name_dat);    % Get Complete Input Filename.
% Get  .DAT  File Info.
[dat_typ, opencmd, loadcmd, descr] = finfo(name_dat_full);
dat_len = length(descr);                                % Length of  .DAT  File.
name_inf_full = strrep(name_dat_full,'.dat','.inf');    % Get .INF Filename.
name_out = deblank(get(handles.val_nameout,'String'));
name_out_full = fullfile(cur_dir, name_out);    % Get Complete Output Filename.
% Get String Info (or Set if is necessary).
string_info = inf2str(name_inf_full);           % Load .INF File.
if ~length(string_info)
    string_info = win2str(handles);
end
[shrt_vars, autodlg_flag] = str2var(string_info, dat_len);
if isempty(shrt_vars)
    return
end
eval(shrt_vars)
% Get HF Channel Properties.
types_hf = get(handles.val_typehf,'String');
type_hf = char(types_hf(get(handles.val_typehf,'Value'),:));
[dummy_a, fname, ename] = fileparts(name_inf_full);
name_inf = [fname, ename];
% Control DAT_TYPE, SIG_LEN and F_S Values. Manual Settings if need.
if isempty(dat_type)|isempty(sig_len)|isempty(f_s)
%    all_files = dir(cur_dir);
%    all_lens = [all_files.bytes];
%    indx_dat = find(ismember({all_files.name},name_dat));
%    dat_len = all_lens(indx_dat);
%    [dat_type, sig_len, f_s, ur_comms] = ...
%        var2var(dat_len, dat_type, sig_len, f_s, add_comms);
    if isempty(dat_type)|isempty(sig_len)|isempty(f_s)
        return      % Intelligence Control was Aborted.
    end
    str2inf(string_info, name_inf_full)
end
% ************************
%name_dat_full = strrep(name_inf_full,'.inf','.dat');    % Get .DAT Filename.
if ~empty_flag                             % All Datas are restored.
    Sx = dat2sig(name_dat_full, dat_type);
    return                                  % All Necessary Datas are Available.
end

switch type_hf
    case 'manual settings'
        num_wavs = get(handles.val_numwav,'Value'); % Read Dialog Window Datas.
        tim_dels = str2num(get(handles.val_timdel,'String'));
        fad_rate = str2num(get(handles.val_fadrat,'String'));
        dop_sprd = str2num(get(handles.val_dopspr,'String'));
        gro_part = str2num(get(handles.val_growav,'String'));
        dop_shft = str2num(get(handles.val_dopsh, 'String'));
        snr_string = get(handles.val_snr,'String');
        if strcmp(snr_string,'max')
            sn_ratio = 1e2;             % Maximum SNR by Default is 100 dB.
        else
            sn_ratio = str2num(snr_string);
        end                             % Set Extended Format.
        input_vars = {name_dat_full, num_wavs, tim_dels, fad_rate, dop_sprd, ...
                gro_part, dop_shft, sn_ratio, name_out_full, f_s, dat_type};
    otherwise                           % Set Abbreviated Format.
        [strt, fnsh, tkns] = regexp(type_hf,'\s+(Good|Moderate|Poor)$');
        type_hf = type_hf(tkns{1}(1):tkns{1}(2));
        input_vars = {name_dat_full, type_hf, name_out_full, f_s, dat_type};
end
flag_filr = get(handles.set_filt,'Value');
flag_time = get(handles.set_filt,'Value');
flag_spec = get(handles.set_spec,'Value');
input_vars{end+1} = [flag_filr, flag_time, flag_spec];
% End of prop2hf SubFunction.

% ============================================================
function Sx = dat2sig(name_dat_full, dat_type)
Sx = [];
fid = fopen(name_dat_full);                 % Open .DAT File for reading.
if fid < 0
    [dummy, fname, ename] = fileparts(name_dat_full);
    name_dat = [fname, ename];
    errordlg(sprintf('Cannot read file ''%s''.', name_dat), 'Disk Error','modal')
    return
end
Sx = fread(fid, dat_type);                  % Load File of Signal.
fclose(fid);
% End of DAT2SIG SubFunction.

% ============================================================
% [EOF] HFSIM

% 777 Force-Majeure Cool&Happy Programming.   � Smirnoff, 2005.