function varargout = siggen(varargin)
% SIGGEN (Signal Generator) is an independent command that allows you
%   to listen/save 8 Phase-Shift Keying (8-PSK) Signal of Random Integer Source.
%       Extension must consist of three symbols, '.DAT' extension recommended.
%       Output produced a 16-bit Integer Format (int16).
%   NOTE: SIGGEN M-file used SIGGEN.fig window.
%
%   Possible SIGGEN Formats are:
%
%    1) SIGGEN calls SIGGEN Dialog Window, werein realized all helps;
%
%    2) OUT_FILE = SIGGEN
%        where OUT_FILE is a Filename of Last Saved File (int16 format),
%        or an int16 Vector of Last Listened File.
%        All properties below are fall into Last either Saved or Listened File
%        (these both are named Generated Signal);
%
%    3) [OUT_FILE, F_S] = SIGGEN
%        where F_S is a Sampling Frequency of Generated Signal, Hz;
%
%    4) [OUT_FILE, F_S, SIG_LEN] = SIGGEN
%        where SIG_LEN is Length of Generated Signal, s;
%
%    5) [OUT_FILE, F_S, SIG_LEN, F_C] = SIGGEN
%        where F_C is a Signal Simple-formed Carrier Frequencies Vector
%           (if Multifrequency Signal Generated), or a Carrier Frequency
%           (if Single-Channel Signal Generated) of Generated Signal, Hz.
%
%   Turn your attention that it is impossible to recover Sampling Frequency from
%   saved .DAT file. You must remember this value or include it into filename.
%
% See also: HFSIM, HFCHANNEL.

% Begin initialization code (DO NOT EDIT!)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @siggen_OpeningFcn, ...
                   'gui_OutputFcn',  @siggen_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
elseif nargin
    error('Too many input arguments.')
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code (DO NOT EDIT!)

% --- Executes just before SIGGEN is made visible.
function siggen_OpeningFcn(hObject, eventdata, handles, varargin)
% Update HFSIM File List (if exist).
h = get_handles_hfsim;
if isstruct(h)                     % No HFSIM Object exists.
    cur_dir = get(h.handle_dir,'TooltipString');
else
    cur_dir = [cd, filesep];
end
set(handles.val_directory,'TooltipString',cur_dir)
guidata(hObject, handles);                  % Update handles structure.
% uiwait(handles.figure1);                % SIGGEN wait for user response.
% End of siggen_OpeningFcn SubFunction.

% --- Outputs from this function are returned to the command line.
function varargout = siggen_OutputFcn(hObject, eventdata, handles)
varargout{1} = 'SIGNAL GENERATOR Window Aborted.';
varargout{7} = [];
if ~length(ishandle(handles))
    return                  % Correct x-Close Dialog Window.
end
cur_dir = get(handles.val_directory,'TooltipString');
set(handles.val_directory,'String',cur_dir)
test_flag = get(handles.figure1,'UserData');
props = get(handles.button_save,'UserData');
if ~length(props)
    props = get(handles.button_listen,'UserData');
end
if length(props)            % Properties Vector of Last Saved/Listened Signal.
    % Set Sx, F_S, SIG_LEN, F_C, CUR_DIR and OUT_FILE properties.
    varargout(:) = deal(props(:));
elseif test_flag
    varargout{1} = 'Test Mode of SIGNAL GENERATOR.';
end
if ~test_flag
    delete(hObject)
end
% End of siggen_OutputFcn SubFunction.

% --- Executes during object creation, after setting all properties.
function val_typsig_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on selection change in val_typsig.
function val_typsig_Callback(hObject, eventdata, handles)
set(handles.button_save,'Enable','on')
set(handles.button_save,'String','Save')
typ_sig = get(hObject,'Value');
if typ_sig == 3
    typ_change(handles,'of')
else
    typ_change(handles,'on')
end
% End of val_typsig_Callback SubFunction.

% --- Executes during object creation, after setting all properties.
function val_siglen_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function val_siglen_Callback(hObject, eventdata, handles)
set(handles.button_save,'Enable','on')
set(handles.button_save,'String','Save')
% End of val_siglen_Callback SubFunction.

% --- Executes during object creation, after setting all properties.
function val_fmin_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function val_fmin_Callback(hObject, eventdata, handles)
set(handles.button_save,'Enable','on')
set(handles.button_save,'String','Save')
% End of val_fmin_Callback SubFunction.

% --- Executes during object creation, after setting all properties.
function val_fc_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function val_fc_Callback(hObject, eventdata, handles)
set(handles.button_save,'Enable','on')
set(handles.button_save,'String','Save')
% End of val_fc_Callback SubFunction.

% --- Executes during object creation, after setting all properties.
function val_fmax_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function val_fmax_Callback(hObject, eventdata, handles)
set(handles.button_save,'Enable','on')
set(handles.button_save,'String','Save')
% End of val_fmax_Callback SubFunction.

% --- Executes during object creation, after setting all properties.
function val_fs_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function val_fs_Callback(hObject, eventdata, handles)
set(handles.button_save,'Enable','on')
set(handles.button_save,'String','Save')
% End of val_fs_Callback SubFunction.

% --- Executes on button press in button_listen.
function button_listen_Callback(hObject, eventdata, handles)
handles_siggen = gcf;
Sx = [];
% --- LISTEN Session Begins.
set(get(handles_siggen,'Children'),'Enable','of')
set(handles_siggen,'Pointer','watch')
pause(0)
props = check_props(handles, 'LISTEN');
if isempty(props)
    set(get(handles_siggen,'Children'),'Enable','on')
    set(handles_siggen,'Pointer','arrow')
    return                  % A mistake take place.
end
% Get Current Properties of Signal to Saving.
[Sx, f_s, sig_len, f_c] = deal(props{1:4});
[cur_dir, name_dat, dat_type] = deal(props{5:7});
set(handles.button_listen,'String','Sound')
%pause(0)
soundsc(Sx, f_s)
pause(sig_len)
set(handles.button_listen,'String','Listen')
set(get(handles_siggen,'Children'),'Enable','on')
set(handles_siggen,'Pointer','arrow')
% End of button_listen_Callback SubFunction.

% --- Executes during object creation, after setting all properties.
function val_directory_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function val_directory_Callback(hObject, eventdata, handles)
cur_dir = get(handles.val_directory,'String');  % Read Input Directory.
if isempty(cur_dir)
    cur_dir = get(handles.val_directory,'TooltipString');
else                                            % Set True Diretory name.
    cur_dir(find((cur_dir=='/')|(cur_dir=='\'))) = filesep;
    [dummy, count] = find([' ',cur_dir]==[cur_dir,' ']);
    cur_dir(count(find(cur_dir(count)==filesep))) = [];
    cur_dir = deblank(cur_dir);
    if cur_dir(end) ~= filesep
        cur_dir(end+1) = filesep;
    end
    if exist(cur_dir,'dir') == 7
        set(handles.val_directory,'TooltipString',cur_dir)
    else
        cur_dir = get(handles.val_directory,'TooltipString');
    end
end
set(handles.val_directory,'String',cur_dir)
set(handles.button_save,'Enable','on')
set(handles.button_save,'String','Save')
% End of val_directory_Callback SubFunction.

% --- Executes on button press in button_setdir.
function button_setdir_Callback(hObject, eventdata, handles)
cur_dir = uigetdir(get(handles.val_directory,'TooltipString'));
if ischar(cur_dir)          % If Uigetdir Output is of CHAR, then its true.
    set(handles.val_directory,'TooltipString',[cur_dir,filesep])
    set(handles.val_directory,'String',[cur_dir,filesep])
    set(handles.button_save,'Enable','on')
    set(handles.button_save,'String','Save')
end
% End of BUTTON_SETDIR SubFunction.

% --- Executes during object creation, after setting all properties.
function val_namein_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

function val_namein_Callback(hObject, eventdata, handles)
set(handles.button_save,'Enable','on')
set(handles.button_save,'String','Save')
% End of val_namein_Callback SubFunction.

% --- Executes during object creation, after setting all properties.
function val_dattype_CreateFcn(hObject, eventdata, handles)
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

% --- Executes on selection change in val_dattype.
function val_dattype_Callback(hObject, eventdata, handles)
% Set Data Type (Precision) Commentary.
val_ranges = {'-128...+127 (integers)','0...255 (integers)', ...
        '-32768...+32767 (integers)','-1...1 (rational)','-1...1 (rational)'};
comment = ['Range is ',val_ranges{get(handles.val_dattype,'Value')},'.'];
set(handles.val_dattype,'TooltipString',comment)
set(handles.button_save,'Enable','on')
set(handles.button_save,'String','Save')
% End of val_dattype_Callback SubFunction.

% --- Executes on button press in button_save.
function button_save_Callback(hObject, eventdata, handles)
handles_siggen = gcf;
Sx = [];
props = check_props(handles, 'SAVE');
if isempty(props)
    set(handles.button_save,'String','Save','Enable','on')
    return                  % A mistake take place.
end
% --- SAVE Session Begins.
% Get Current Properties of Signal to Saving.
[Sx, f_s, sig_len, f_c, cur_dir, name_dat, dat_type] = deal(props{:});
name_dat_full = fullfile(cur_dir, name_dat);    % Get Full .DAT Filename.
% Check: is Current Signal exist?
if exist(name_dat_full) == 2
    button = questdlg([sprintf('File named  ''%s''  already exist.\n', ...
            name_dat), 'Overwrite it?'], 'SIGGEN Question');
    if ~length(button) | ~strcmp(button, 'Yes')
        set(handles.button_save,'String','Save','Enable','on')
        return
    end
end
set(get(handles_siggen,'Children'),'Enable','of')
set(handles_siggen,'Pointer','watch')
pause(0)
% Current Signal exists. Save .INF File.
name_inf_full = strrep(name_dat_full,'.dat','.inf');    % Get Full .INF Filename.
string_info = win2str(handles);         % Set Info String from Dialog Window.
% Save .INF File (mistake is impossible).
str2inf(string_info, name_inf_full)
% Convert Double Format of Generated Signal (if need).
powr = dat_type(find(dat_type=='1'|dat_type=='6'|dat_type=='8'));
if isempty(powr)                % Double or Single Format sets.
    powr = '0';
end                             % Data Format Convertation (strictly).
Sx = eval([dat_type,'(pow2(',powr,')*Sx);']);
% Save .DAT File.
set(handles.button_save,'String','Saving')
fid = sig2dat(Sx, name_dat_full);
set(handles.button_save,'String','Save')
% Check: if a mistake take place.
if fid < 0
    return
end
set(get(handles_siggen,'Children'),'Enable','on')
set(handles_siggen,'Pointer','arrow')
%pause(0)
% Update HFSIM File List (if exist).
h = get_handles_hfsim;
if ~isstruct(h)                     % No HFSIM Object exist.
    return
end
cur_dir_hf = get(h.handle_dir,'TooltipString');
if ~strcmp(cur_dir_hf, cur_dir)
    return              % SIGGEN refers to another Directory that HFSIM.
end
% Search .DAT Files inside both SIGGEN&HFSIM Current Directory.
dat_files = dir([cur_dir_hf,'*.dat']);
dat_names_cell = {dat_files.name};                      % Get List of .DAT Files.
file_pos = find(ismember(dat_names_cell,{name_dat}));   % Find New File Position.
% Search Handles of Input Filenames Listing.
set(h.handle_names,'String', char(dat_names_cell), ...  % Set Generated Filename.
    'Value', file_pos, ...                  % Set Generated Filename Position.
    'TooltipString', string_info)           % Set Info String of Signal.
% Switch ON HFSIM Buttons.
set(h.handle_listen, 'Enable','on')
set(h.handle_delete, 'Enable','on')
set(h.handle_starthf,'Enable','on')
% End of button_save_Callback SubFunction.

function h = get_handles_hfsim
h = 0;
childs_comm = get(0,'Children');
all_objnms = get(childs_comm,'Name');   % Get List of Existed Objects.
if ischar(all_objnms)                   % HFSIM not exist.
    return
end
all_objnms_str = char(all_objnms{:});
indx_hfsim = strmatch('High Frequency Channel', all_objnms_str);
if ~length(indx_hfsim)                  % HFSIM not exist.
    return
end
% Create HFSIM zero-state structure array.
h = struct('handle_dir',     0, ...
           'handle_names',   0, ...
           'handle_listen',  0, ...
           'handle_delete',  0, ...
           'handle_starthf', 0);
% Get Handles of HFSIM Object.
handles_hfsim = get(childs_comm(indx_hfsim),'Children');
% Search Handles of Current Directory.
h.handle_dir     = findobj(handles_hfsim,'Tag','val_directory');
% Search Handles of Input Filenames Listing.
h.handle_names  = findobj(handles_hfsim,'Tag','val_namein');
% Search Handles of LISTEN Button.
h.handle_listen  = findobj(handles_hfsim,'Tag','button_listen');
% Search Handles of DELETE Button.
h.handle_delete  = findobj(handles_hfsim,'Tag','button_delete');
% Search Handles of START HF Button.
h.handle_starthf = findobj(handles_hfsim,'Tag','button_starthf');
% End of GET_HANDLES_HFSIM SubFunction.

% --- Manual Subfunctions (MSFs).
function typ_change(handles,action)
% Switching between MultiFrequency & Single-Frequency Signal Properties.
set(handles.text_fmin,'visible',action), set(handles.text_fmax,'visible',action)
set(handles.val_fmin, 'visible',action), set(handles.val_fmax, 'visible',action)
set(handles.text_Hz1, 'visible',action), set(handles.text_Hz3, 'visible',action)
if strcmp(action,'on')
    action = 'of';          % Inverse action.
else
    action = 'on';
end
set(handles.text_fc, 'visible',action)
set(handles.val_fc,  'visible',action)
set(handles.text_Hz2,'visible',action)
% End of TYP_CHANGE SubFunction.

function Sx = sig_gen(f_s, sig_len, f_c);
% Eight Phase-Shift Keying (8-PSK) int16 Signal Generator.
% *********** SET SIGNAL PROPERTIES ***********
M = 8;                                      % Phase-Shift Keying Order.
tau = 0.25;                                 % Length of Signal Sending, s.
% *********** USE SIGNAL PROPERTIES ***********     (Calculations)
n_tau = ceil(sig_len/tau);                  % Number of Full Sendings per Signal.
inform = randint(size(f_c,2),n_tau,M);      % Model of Random Integer Source.
sig_len_0 = tau*n_tau;                      % Recalculation of Signal Length, s.
t = [0:1/f_s:sig_len_0-1/f_s];              % Time Discrets, s.
phase_c = 2*pi*f_c'*t;                      % Current Phase, rad.
N = ceil(f_s*tau);                          % Number of Samples per each Sending.
phase_0 = 2*pi/M*reshape(repmat(inform,N,1),size(inform,1),size(inform,2)*N); % Initial Phase, rad.
phase_0(:,size(phase_c,2)+1:end) = [];      % Cut unnecessary part of Initial Phase.
Sx = sum(sin(phase_c + phase_0)',2);        % Sought Signal in Double Format.
Sx = Sx/max(abs(Sx));                       % Normalization of Sought Signal.
% End of SIG_GEN SubFunction.

function props = check_props(handles, button_name)
handles_siggen = gcf;
[props, f_s, sig_len, f_c] = deal([]);      % Set Signal Default Properties.
% Read New (Actual) Signals Properties.
props_cur = win2prop(handles, button_name);
if isempty(props_cur)
    return                                  % A mistake take place.
end
% Set WAIT Mode.
if strcmp(upper(button_name),'LISTEN')
    set(handles.button_listen,'String','Busy...','Enable','of')
else
    set(handles.button_save,'String','Busy...','Enable','of')
end
%pause(0)
% Read Old (Previous) Signals Properties.
props_listen = get(handles.button_listen,'UserData');
props_save = get(handles.button_save,'UserData');
% Get Signal discrets (in Double Format).
if length(props_listen)                     % LISTEN Button was Activated earlier.
    if isequal(props_listen(2:4),props_cur(2:4))
        [Sx, f_s, sig_len, f_c] = deal(props_listen{1:4});
    end
end
if length(props_save)               % SAVE Button was Activated earlier.
    if isequal(props_save(2:4),props_cur(2:4))
        [Sx, f_s, sig_len, f_c] = deal(props_save{1:4});
    end
end
if ~length([f_s, sig_len, f_c])
    [f_s, sig_len, f_c] = deal(props_cur{2:4});
    Sx = sig_gen(f_s, sig_len, f_c);            % Get Signal in double format.
end
% Save Properties & Set READY Mode.
if strcmp(upper(button_name),'LISTEN')
    props = {Sx, f_s, sig_len, f_c, '', '', ''};
    set(handles.button_listen,'UserData',props)
else
    [cur_dir, name_dat, dat_type] = deal(props_cur{5:7});
    props = {Sx, f_s, sig_len, f_c, cur_dir, name_dat, dat_type};
    set(handles.button_save,'UserData',props)
end
%pause(0)
% End of  CHECK_PROPS  SubFunction.

function props_cur = win2prop(handles, button_name)
props_cur = [];
% 1) Get Current Signal Sampling Frequency (-ies).
f_s = 1e3*str2num(get(handles.val_fs,'String'));    % Fs: convert kHz to Hz.
if prod(size(f_s)) ~= 1  |  f_s <= 0
    errordlg('Correct Sampling Frequency Value, Hz.','Error','modal')
    set_default(handles.val_fs)
    return
end
% 2) Get Signal Length, s.
sig_len = str2num(get(handles.val_siglen,'String'));
if prod(size(sig_len)) ~= 1  |  sig_len <= 0
    errordlg('Correct Length of Signal Value, s.','Error','modal')
    set_default(handles.val_siglen)
    return
end
% 3) Get Current Signal Carrier Frequency (-ies).
num_subs = [60, 12, 1];         % Available number of subchannels.
num_sub = num_subs(get(handles.val_typsig,'Value'));    % Actual number of subchannels.
if any(num_sub==[60,12])        % (1,2) If Multifrequency (60/12) Signal Choosed.
    f_min = str2num(get(handles.val_fmin,'String'));
    if prod(size(f_min)) ~=1  |  f_min <= 0
        errordlg('Correct Lower Frequency Value, Hz.','Error','modal')
        set_default(handles.val_fmin)
        return
    end
    f_max = str2num(get(handles.val_fmax,'String'));
    if prod(size(f_max)) ~= 1  |  f_max <= 0
        errordlg('Correct Higher Frequency Value, Hz.','Error','modal')
        set_default(handles.val_fmax)
        return
    end
    if f_min >= f_max
        errordlg([sprintf(['Lower Frequency Value  f_min = %d Hz  ', ...
                    'must much\nthe Higher Frequency Value  '], f_min), ...
                sprintf('f_max = %d Hz,  conversely.', f_max)], 'Error','modal')
        set_default(handles.val_fmin)
        set_default(handles.val_fmax)
        return
    end
    if 2*f_max >= f_s
        errordlg([sprintf(['Duplicated Higher Frequency of Signal ', ...
                    ' 2 f_max = %d Hz\n'], 2*f_max), sprintf(['exceeds ', ...
                    'the Sampling Frequency  f_s = %d  Hz.'], f_s)], ...
            'Error','modal')
        set_default(handles.val_fmax)
        set_default(handles.val_fs)
        return
    end
    % Simple-formed Carrier Frequencies Vector, Hz.
    f_c = linspace(f_min,f_max,num_sub);
else                            % (3) If Single-Frequency Signal Choosed.
    f_c = str2num(get(handles.val_fc,'String'));    % Carrier Frequency, Hz.
    if prod(size(f_c)) ~= 1  |  f_c <= 0
        errordlg('Correct Carrier Frequency Value.','Error','modal')
        set_default(handles.val_fc)
        return
    end
end
if strcmp(upper(button_name),'LISTEN')
    ai = analoginput('winsound');           % Get PC Sound Card Capabilities.
    f_s_range = deal(daqhwinfo(ai,{'MinSampleRate','MaxSampleRate'}));
    if f_s < f_s_range{1}  |  f_s > f_s_range{2}
        errordlg([sprintf('Invalid Sampling Frequency Value for your PC:\n'), ...
                sprintf('Possible Values are in the Range [%d; ', f_s_range{1}), ...
                sprintf('%d] Hz.',f_s_range{2})],'Error','modal')
        set_default(handles.val_fs)
        return
    end
    % Form Vector of Current Signal Properties.
    props_cur = {[], f_s, sig_len, f_c, '', '', ''};
    return
end
% Following Actions are Intended to SAVE Button.
% 4) Get Current Signal Directory.
cur_dir = get(handles.val_directory,'TooltipString');
% 5) Get Current Signal Filename.
name_dat = deblank(get(handles.val_namein,'String'));
[dname, fname, ename] = fileparts(name_dat);
if length(dname) | ~length(fname) | ~isvarname(fname) | ...
        length(ename) ~= 4 | ~isvarname(ename(2:end))
    errordlg('Correct Filename and/or its Extention.','Error','modal')
    set(handles.val_namein,'String','my_in.dat')
    return
end
set(handles.val_namein,'String',name_dat)    % Correct Filename.
% 6) Get Precision (Data Type).
dat_types = get(handles.val_dattype,'String');
dat_type = dat_types{get(handles.val_dattype,'Value')};
% 7) Form Vector of Current Signal Properties.
props_cur = {[], f_s, sig_len, f_c, cur_dir, name_dat, dat_type};
% End of CHECK_PROPS SubFunction.

function set_default(handle_val)
default_str = get(handle_val,'TooltipString');
ind_start = max(find(isspace(default_str)));
set(handle_val,'String',default_str(ind_start+1:end))
% End of SET_DEFAULT SubFunction.

function str2inf(string_info, name_inf_full)
% Create Filename '.INF'.
fid = fopen(name_inf_full, 'w');        % Open .INF File for writing.
if fid < 0
    return                              % No Error Comments.
end
fwrite(fid, string_info, 'uchar');      % Save Info of Signal File.
fclose(fid);
% End of str2inf SubFunction.

function fid = sig2dat(Sx, name_dat_full)
fid = fopen(name_dat_full, 'w');        % Open .DAT File for writing.
if fid < 0
    [dummy, fname, ename] = fileparts(name_dat_full);
    name_dat = [fname, ename];
    errordlg(['Cannot create file ', '''', name_dat, '''.'], ...
        'SIGGEN Disk Error','modal')
    return
end
fwrite(fid, Sx, class(Sx));              % Save .DAT File.
fclose(fid);
% End of sig2dat SubFunction.

function string_info = win2str(handles)
% Set String to be Saved (Read from Dialog Window).
name_dat = deblank(get(handles.val_namein,'String'));   % Read Filename.
dat_types = get(handles.val_dattype,'String');          % Possible Data Types.
dat_type = dat_types{get(handles.val_dattype,'Value')}; % Read Data Type.
typ_sigs = get(handles.val_typsig,'String');
val_sig = get(handles.val_typsig,'Value');
typ_sig = typ_sigs{val_sig};                            % Read Type of Signal.
sig_len_str = get(handles.val_siglen,'String');
str_s = char(32*ones(1,20));        % Sequence of Spaces to Design String Info.
str_1 = sprintf('Filename of Signal: ''%s''.', name_dat);
str_2 = sprintf('\n\nData Type: ''%s''.', dat_type);
str_3 = sprintf('\n\nType of Signal:  %s.', upper(typ_sig));
str_4 = sprintf('\n\nSignal Properties:\n');
str_5 = sprintf(['\n', str_s, 'sig_len = %s s;'], sig_len_str);
if val_sig ~= 3                                 % Multifrequency Signal used.
    f_min_str = get(handles.val_fmin,'String');
    f_max_str = get(handles.val_fmax,'String');
    str_6 = sprintf(['\n', str_s, 'f_min = %s Hz;'], f_min_str);
    str_7 = sprintf(['\n', str_s, 'f_max = %s Hz;'], f_max_str);
else                                            % Single-Frequency Signal used.
    f_c_str = get(handles.val_fc,'String');
    str_6 = sprintf(['\n', str_s, 'f_c = %s Hz;'], f_c_str);
    str_7 = '';
end
f_s_str_kHz = get(handles.val_fs,'String');     % Read Sampling Frequency, kHz.
f_s_str_Hz = num2str(1e3*str2num(f_s_str_kHz)); % Read Sampling Frequency, Hz.
str_8 = sprintf(['\n', str_s, 'f_s = %s Hz.'], f_s_str_Hz);
string_info = [str_1, str_2, str_3, str_4, str_5, str_6, str_7, str_8];
% End of WIN2STR SubFunction.

% [EOF] SIGGEN

% 777 Force-Majeure Cool&Happy Programming.   � Smirnoff, 2005.