function varargout = hfchannel(varargin)
% HFCHANNEL High-Frequency (3..30 MHz) Channel according to ITU-R F.1487.
%        Is suitable in respect of tone frequency (300...3400 Hz) signal.
%        Watterson Model of High-Frequency (HF-) Channel Simulator used.
%
%   SYNTAX
%
%  1) HFCHANNEL, by itself, calls  HFSIM  module,
%        which completely overlays  HFCHANNEL  capabilities listed below;
%
%  2) HFCHANNEL(INPUT_FILE, TYPE_HF, OUTPUT_FILE, Fs, DAT_TYPE);
%                          /       \                (abbreviated format)
%         /---------------/         \----------------------------------------\
%  3) ...| NUM_WAVS, TIM_DEL, FAD_RATE, DOP_SPRD, GRO_PART, DOP_SHFT, SNR_VAL | ...
%                                                      (extended format)
%
%  where INPUT_FILE is Input Signal Long Filename, extension is '.dat'
%           (if Short Filename used then Current Directory sets);
%        TYPE_HF can be GOOD, MODERATE or POOR according to ITU-R F.1487
%           (if  TYPE_HF = []  then  TYPE_HF = 'MODERATE'  sets);
%        NUM_WAVS is number of skywaves of HF Channel on Receiver Side
%           (if  NUM_WAVS = 1  and  GRO_PART = 0%  then  TIM_DELS = 0 ms);
%        TIM_DEL is differential time delay between waves, ms;
%        FAD_RATE is Fading Rate of Received Signal, fadings per minute
%           (if  FAD_RATE = []  then  DOP_SPRD must be determined);
%        DOP_SPRD is Doppler Spread of waves, Hz
%           (if  DOP_SPRD = []  then  FAD_RATE must be determined);
%        GRO_PART is Ground Wave part in Received Signal, %
%           (if  GRO_PART = []  then  GRO_PART = 0%  sets);
%        DOP_SHFT is Constant Doppler Shift of Received Signal, Hz
%           (if  DOP_SHFT = []  then  DOP_SHFT = 0 Hz  sets);
%        SNR_VAL is Constant Signal-to-Noise Ratio, dB
%           (if  SNR_VAL = []  then  SNR_VAL = 100 dB  sets);
%        OUTPUT_FILE is Output Signal Long Filename, extension is '.dat'
%           (if Short Filename used then Current Directory sets);
%        Fs is Sampling Frequency, Hz (if Fs = []  then  Fs = 8000 Hz);
%        DAT_TYPE is Precision of INPUT_FILE/OUTPUT_FILE Datas,
%           can be either 'int8', 'uint8', 'int16', 'single' or 'double'
%           (if absent or  DAT_TYPE = []  then  DAT_TYPE = 'int16'  sets);
%
%  4) Sy = HFCHANNEL(Sx, TYPE_HF, Fs);              (abbreviated format)
%                       /       \-------------\
%  5) Sy = HFCHANNEL(Sx, NUM_WAVS, ..., SNR_VAL, Fs);  (extended format)
%
%  6) Also possible specific vector of flags writes after SNR_VAL:
%        [FLAG_FILR, FLAG_TIME, FLAG_SPEC],
%
%  where FLAG_FILR is ;
%        FLAG_TIME is ;
%        FLAG_SPEC is .
%
%   EXAMPLES
%
%     - abbreviated format:
%
%        1) HFCHANNEL(name_in, 'Poor', name_out, 8000, 'int16', [0 1 0]);
%        2) Sy = HFCHANNEL(Sx, 'Moderate', 8000);
%
%     - extended format:
%
%        3) HFCHANNEL(name_in, 2,  1,  [], 2,  0, -5, 36, name_out, 8000, 'int16');
%        4) Sy = HFCHANNEL(Sx, 3, 1.5, 22, [], 50, 0, 12, 8000, [0 1 1]);
%
%  where  name_in  = 'C:\MATLAB6p5\work\my_in.dat';
%         name_out = 'C:\MATLAB6p5\work\my_out.dat'.
%
%   See also HFSIM, SIGGEN.

% Type also  helpwin hfchannel.

if nargout
    varargout{1} = [];
end
errorshow('AAA')
% Control of input arguments.
hf_props = varargs_read(varargin, nargout);
if ~length(hf_props)
    return                          % Mistake take place.
end
% Control of output arguments.
if nargout > 1
    errorshow('Too many output arguments.')
    return
end
% System definitions.
[Sx  f_s  dat_type  type_hf  num_wavs  tim_del  fad_rate  dop_sprd  gro_part ...
        dop_shft snr_val name_dat_full name_out_full flags] = deal(hf_props{:});
[flag_filr  flag_time  flag_spec] = deal(flags(1), flags(2), flags(3));
tx = 1:length(Sx);              % Length of transmitted signal, discrets.
Tx = tx(end)/f_s;               % Length of transmitted signal, s.
tim_dels = repmat(tim_del,1,num_wavs);  % Forming time delays between waves.
q_skies = ones(1, num_wavs);    % Normalize rays q(i) to [0;1] interval.
fad_rate = fad_rate/60;         % Convert Fading Rate to Hz.
alpha_gro = 1e-2*gro_part;      % Convert Ground Wave part to (0..1).
tau_skies = round(f_s*tim_dels*1e-3);   % Convert Time Delays to discrets.
Sy = 0; q = [];
% Start the Simulator.
if (num_wavs > 1) & (alpha_gro < 1)     % If fadings are presence.
    % **********WAVE SKIES COEFFICIENTS GENERATOR**************
    % Design the elliptical digital Low-Pass Filter. Order is 3;
    % bandpass unevenness: 0.1 dB; minimum weakening: 50 dB.
    cut_freq = .588705*dop_sprd;                % Filter's cutoff frequency, Hz.
    [b, a] = ellip(3, 0.1, 50, 2*cut_freq/f_s);  % Calculate an elliptical filter coeffs.
    [H, w] = freqz(b, a, 2^16);
    plot_filter_1(f_s, fad_rate, w, H, flag_filr);
    % Get Complex Coefficients of Watterson Model.
    add = 1e5;                          % Additional part of realisation.
    unvisib = 7e4;                  % Unvisible part of realisation for filtering.
    for n = 1:num_wavs              % Process of complex coefficients variation.
        s = 2*rand(2, unvisib+tx(end)+add) - 1; % Random inputs of the filter.
        qcur1 = filter(b, a, s(1,:));           % Filtering process.
        qcur2 = filter(b, a, s(2,:));
        qcur1 = qcur1(unvisib+1:end);   % Clear unvisible part of realization.
        qcur2 = qcur2(unvisib+1:end);
        qcur1 = qcur1/max(abs(qcur1));  % Normalising along whole realization.
        qcur2 = qcur2/max(abs(qcur2));
        qcom = q_skies(n)*(qcur1 + j*qcur2);% Complex numeration of coefficients.
        q = [q; qcom];                      % Matrix upgrade.
    end
    % Skywave & histogram of coefficients realisations.
    plot_filter_2(f_s, q, tx, flag_filr);
    taus = sum(tau_skies);
    q(:, end-add+1+taus:end) = [];      % Delete additional part of realization.
    % **************HF IMITATOR BY WATTERSON*******************
    Sx_h = hilbert(Sx);                 % Hilbert transformation.
    for m = 1:num_wavs                  % By all complex skywaves.
        delay = sum(tau_skies(1:m));    % Time delay of current skywave.
        Sx_cur = [zeros(1,delay), Sx_h, zeros(1,taus-delay)];   % Delay skywave.
        Sy = Sy + real(q(m,1:length(Sx_cur)).*Sx_cur);  % Multipling whith vector q(m).
    end
    Sy = sqrt(alpha_gro)*[Sx zeros(1, taus)] + ...      % Add ground wave part.
        sqrt(1 - alpha_gro)*Sy;
else
    Sy = Sx;                                % If fadings are absent.
end
% Doppler shifting.
ty = 1:length(Sy);                          % Length of received signal, discrets.
Ty = ty(end)/f_s;
if dop_shft
    shift = exp(j*2*pi*dop_shft*Ty*ty/max(ty));     % Constant Doppler shift.
    Sy = real(shift.*hilbert(Sy));          % Shift the transmitted signal.
end
% AWGN adding (launch a Gaussian noise generator).
Sy = awgn(Sy, snr_val, 'measured');         % Add AWGN of required power, dB.
plot_time(Sy, hf_props{[1,2,13]});          % Realizations creation.
plot_spec(Sy, hf_props{[1,2,11,12,10,13]}); % Spectrogramms creation.
% Convert Double Format of Generated Signal (if need).
pow_2 = dat_type(find(dat_type=='1'|dat_type=='6'|dat_type=='8'));
if isempty(pow_2)               % Double or Single Format sets.
    pow_2 = '0';
end                             % Data Format Convertation (strictly).
Sx_formatted = eval([dat_type, '(2^',pow_2,'*Sx);']);
% Exit the HF Channel Simulator.
if length(name_dat_full)        % Files Creation.
    fid = sig2dat(Sx_formatted, name_dat_full);
    if fid < 0
        return
    end
    string_info = var2str(hf_props);
    str2inf(string_info, name_inf_full)
elseif nargout
    varargout{1} = Sy;
end


% ***************BASIC SUBFUNCTIONS****************************
function errorshow(error_str)
trace_info = dbstack;
pat = '\w*\s[(]button_starthf_Callback[)]';
strt = regexp([trace_info.name],pat);
if length(strt)
    errordlg(error_str,'HFCHANNEL Error','modal')
else
    error(error_str)
end

function hf_props = varargs_read(varargin, nargout)
hf_props = [];
% Set Format of Input/Output Arguments.
args_fmt = 'hf_xxxx_xx';
if ~length(varargin)
    hfsim                       % HFSIM runs.
    return
end
nargin_str = dec2base(length(varargin),10,2);
args_fmt(9:10) = nargin_str;
if ~nargout                     % Works whith Files.
    args_fmt(4:7) = 'fils';
elseif nargout == 1             % Works whith Variables (Output Signal is Sy).
    args_fmt(4:7) = 'vars';
end
%   Possible Formats are:
% 'hf_fils_05': FILE_IN, TYPE_HF, FILE_OUT, F_S, DAT_TYPE.
% 'hf_fils_06': Previous Format plus [FLAG_FILR, FLAG_TIME, FLAG_SPEC].
% 'hf_fils_11': TYPE_HF Replaced with
%   NUM_WAVS, TIM_DEL, FAD_RATE, DOP_SPRD, GRO_PART, DOP_SHFT, SNR_VAL.
% 'hf_fils_12': [FLAG_FILR, FLAG_TIME, FLAG_SPEC] adds.
% 'hf_vars_03': Sx, TYPE_HF, F_S.
% 'hf_vars_04': [FLAG_FILR, FLAG_TIME, FLAG_SPEC] adds.
% 'hf_vars_09': TYPE_HF Replaced with HF Channel Properties (see above).
% 'hf_vars_10': [FLAG_FILR, FLAG_TIME, FLAG_SPEC] adds.
if ~exist('args_fmt')
    errorshow('Invalid Number of Input (Output) arguments.')
    return
end
% Check flags (if defined).
if any(length(varargin) == [4, 6, 10, 12])
    flags = varargin{length(varargin)};
    varargin(end) = [];
    if length(flags) ~= 3 | ~isnumeric(flags)
        errorshow('Take Control Flags of HFCHANNEL.')
        return
    end
else
    flags = ones(1,3);                      % Set Default Flags.
end
% Get HF Channel Properties.
if length(varargin) < 6
    type_hf = upper(varargin{2});
    [num_wavs, tim_del, fad_rate, dop_sprd, gro_part, ...
            dop_shft, snr_val, type_hf] = set_ituprops(type_hf);
else
    manual_props = check_manual(varargin{2:8});
    if ~length(manual_props)
        return
    end
    [num_wavs, tim_del, fad_rate, dop_sprd, gro_part, ...
            dop_shft, snr_val, type_hf] = deal(manual_props{:}, 'UNKNOWN');
end
% Set Filenames or Variables.
if strcmp(args_fmt(4:7),'fils')             % Files are Processing.
    name_dat = varargin{1};
    name_out = varargin{end-2};
    name_dat_full = check_filename(name_dat);
    name_out_full = check_filename(name_out);
    if ~length(name_dat_full) | ~length(name_out_full)
        return
    elseif strcmp(name_dat_full, name_out_full)
        errorshow('Names of Input/Output files must be difference.')
        return
    end
    f_s = varargin{end-1};
    dat_type = varargin{end};
    % Load INPUT_FILE.
    Sx = dat2sig(name_dat_full, dat_type);
    if ~length(Sx)
        return                              % Invalid INPUT FILE.
    end
else                                        % Variables are Processing.
    [name_dat_full, name_out_full] = deal([]);
    f_s = varargin{end};
    dat_type = class(Sx);
end
if prod(size(f_s))~=1 | ~isnumeric(f_s)
    errorshow('F_S Value must be Numeric Scalar.')
    return
end
hf_props = {Sx  f_s  dat_type  type_hf  num_wavs  tim_del  fad_rate  dop_sprd ...
        gro_part  dop_shft  snr_val  name_dat_full  name_out_full  flags};
% End of VARARGS_READ SubFunction.

function manual_props = check_manual(varargin)
%varargin = {num_wavs, tim_del, fad_rate, dop_sprd, gro_part, dop_shft, snr_val}
manual_props = [];
% Check: is Numeric?
if ~isnumeric([varargin{:}])
    errorshow('HF Channel Properties must be numeric.')
    return
end
% Check: is not Empty and is Pozitive Scalars?
if (isempty([varargin{1:3}]) & isempty([varargin{[1 2 4]}])) | ...
        any([varargin{[1:5,7]}]~=abs([varargin{[1:5,7]}])) | ...
        prod(size([varargin{:}])) ~= 7 | varargin{1} ~= round(varargin{1})
    errorshow(sprintf(['All HF Channel properties must be scalars.\n\n', ...
            'Only DOP_SHFT value can be negative.\n\n', ...
            'NUM_WAVS value must be integer.\n\n', ...
            'NUM_WAVS,  TIM_DEL  and  DOP_SPRD  (or  FAD_RATE)\n', ...
            'properties must be given.']))
    return
end
% Read Input Arguments.
[num_wavs, tim_del, fad_rate, dop_sprd, gro_part, dop_shft, snr_val] = ...
    deal(varargin{:});
% Fading Rate (Doppler Spread) Control.
fad_rate_new = round(100*60/1.356*dop_sprd)/100;    % Values Balancing.
dop_sprd_new = round(100*1.356/60*fad_rate)/100;
if ~length(dop_sprd) | dop_sprd <= 0 | ~length(fad_rate) | fad_rate <= 0
    if length(fad_rate_new)
        fad_rate = fad_rate_new;
    elseif length(dop_sprd_new)
        dop_sprd = dop_sprd_new;
    end
elseif dop_sprd ~= dop_sprd_new                     % Disputable Case.
    dop_sprd_0 = 1 + eps;                           % Middle Doppler Spread Value.
    trust_dop_old = 1/dist(dop_sprd_0,dop_sprd);    % Set Subject Criteria.
    trust_dop_new = 1/dist(dop_sprd_0,dop_sprd_new);
    if trust_dop_new >= trust_dop_old               % Check Threshold.
        dop_sprd = dop_sprd_new;
        warning(['DOP_SPRD Value sets to ',num2str(dop_sprd),'.'])
    else
        fad_rate = fad_rate_new;
        warning(['FAD_RATE Value sets to ',num2str(fad_rate),' Hz.'])
    end
end
% Groundwave Part Control.
if gro_part < 0 | gro_part > 100
    errorshow('Correct Groundwave Part.')
    return
end
manual_props = {num_wavs tim_del fad_rate dop_sprd gro_part dop_shft snr_val};
% End of CHECK_MANUAL SubFunction.

function [num_wavs, tim_del, fad_rate, dop_sprd, gro_part, dop_shft, ...
        snr_val, type_hf_new] = set_ituprops(type_hf)
[num_wavs, tim_del, fad_rate, dop_sprd, gro_part, dop_shft, ...
        snr_val, type_hf_new] = deal([]);
% Control Type of ITU-R F.1487 HF Channel.
types_hf = {'GO','MO','PO'};
if length(type_hf) < 2 | ~any(ismember(types_hf, deblank(upper(type_hf(1:2)))))
    errorshow(sprintf(['Take Control TYPE_HF of HFCHANNEL.\n', ...
            'Use GOOD, MODERATE or POOR (according to ITU-R F.1487).']))
    return
end
type_hf = deblank(upper(type_hf(1:2)));
% Set ITU-R F.1487 HF Channel Properties.
num_wavs = 2;
gro_part = 0;
dop_shft = 0;
snr_val = 100;          % Maximum SNR, dB.
switch type_hf
    case 'GO'                             % GO-MO-PO Control  :)
        [type_hf_new, tim_del, dop_sprd] = deal(  'GOOD',  .5, 0.1);
    case 'MO'
        [type_hf_new, tim_del, dop_sprd] = deal('MODERATE', 1, 0.5);
    case 'PO'
        [type_hf_new, tim_del, dop_sprd] = deal(  'POOR',   2, 1.5);
end
% End of SET_ITUPROPS SubFunction.

function name_dat_full = check_filename(name_dat)
name_dat_full = [];
name_dat = deblank(name_dat);
[dummy, indcs] = find((name_dat=='\')|(name_dat=='/'));
name_dat(indcs) = filesep;
name_dat(indcs(find(diff([0,indcs])==1))) = [];  % Remove repeated fileseps.
[dname, fname, ename] = fileparts(name_dat);
if ~length(fname) | ~isvarname(fname)
    errorshow(['Correct Filename ''', fname, '''.'])
    return
end
if length(ename) < 2
    ename = '.dat';
    warning(['File ''',fname,''' Extension sets to .DAT.'])
end
if length(ename) > 1 & ~isvarname(ename(2:end))
    errorshow(['Correct Extension of File ''', fname, '''.'])
    return
end
if ~length(dname)
    dname = cd;
end
if ~isdir(dname)
    errorshow([sprintf(['Nonexistent Directory of File ''', [fname ename], ...
                ''':\n']), dname, filesep])
    return
end
name_dat_full = fullfile(dname, [fname, ename]);
% End of CHECK_FILENAME SubFunction.

function Sx = dat2sig(name_dat, dat_type)
Sx = [];
% Check Filename.
name_dat_full = check_filename(name_dat);
if ~length(name_dat_full)
    return
end
% Check Data Formet.
dat_types = {'int8','uint8','int16','single','double'};    % Available formats.
if ~any(ismember(dat_types, dat_type))
    errorshow(sprintf(['Invalid Data Type Format.\n', ...
            'It must be of types int8, uint8, int16, single or double.']))
    return
end
% Read Signal.
fid = fopen(name_dat_full);         % Open int16 INPUT FILE.
if fid < 0                          % If INPUT FILE do not exist.
    return
end
Sx = fread(fid, dat_type);          % Read existing INPUT FILE.
fclose(fid);
Sx = double(Sx');                   % Convert INPUT FILE to double format.
% End of dat2sig SubFunction.

function fid = sig2dat(Sx, name_dat_full)
fid = fopen(name_dat_full, 'w');    % Open .DAT File for writing.
if fid < 0
    [dummy, fname, ename] = fileparts(name_dat_full);
    name_dat = [fname, ename];
    errorshow(['Cannot create file ', '''', name_dat, '''.'])
    return
end
fwrite(fid, Sx, class(Sx));         % Save .DAT File.
fclose(fid);
% End of sig2dat SubFunction.

function str2inf(string_info, name_inf_full)
% Create Filename '.INF'.
fid = fopen(name_inf_full, 'w');    % Open .INF File for writing.
if fid < 0
    return                          % No Error Comments.
end
fwrite(fid, string_info, 'uchar');  % Save Info of Signal File.
fclose(fid);
% End of str2inf SubFunction.

function string_info = var2str(hf_props)
% Get Short INPUT Filename.
name_dat_full = hf_props{12};
[dname, fname, ename] = fileparts(name_dat_full);
name_dat = [fname, ename];
% Get Short OUTPUT Filename.
name_out_full = hf_props{13};
[dname, fname, ename] = fileparts(name_out_full);
name_out = [fname, ename];
% Get Data Type (Precision).
dat_type = hf_props{3};
% Get Full HF Channel Type.
type_hf = hf_props{4};
if ~strcmp(type_hf,'UNKNOWN')
    type_hf = [' ITU-R F.1487 ', upper(type_hf(1)), lower(type_hf(2:end))];
end
% Set Strings to be Saved.
str_s = char(32*ones(1,20));        % Number of Spaces of Signal Properties.
str_1 = ['Filename of Signal: ''', name_out, ''';\n\n'];
str_2 = ['Data Type: ''', dat_type, ''';\n\n'];
str_3 = ['Type of Signal:  RECEIVED\n', ...
        str_s, '(Source File named ', name_dat, ''',\n', ...
        str_s, 'f_s = ', num2str(hf_props{2}), ' Hz);\n\n'];
str_4 = ['Type of Channel:  ', type_hf, ';\n\n'];
str_5 = ['Channel Properties\n'];
str_6 = [str_s, 'num_wavs = ', num2str(hf_props{04}),    ',\n'];
str_7 = [str_s, 'tim_del  = ', num2str(hf_props{05}), ' ms,\n'];
str_8 = [str_s, 'fad_rate = ', num2str(hf_props{06}),' fpm,\n'];
str_9 = [str_s, 'dop_sprd = ', num2str(hf_props{07}), ' Hz,\n'];
str_0 = [str_s, 'gro_part = ', num2str(hf_props{08}),  ' %,\n'];
str_a = [str_s, 'dop_shft = ', num2str(hf_props{09}), ' Hz,\n'];
str_b = [str_s, 'snr_val  = ', num2str(hf_props{10}),   ' dB.'];
string_info = sprintf([str_1, str_2, str_3, str_4, str_5, ...
        str_6, str_7, str_8, str_9, str_0, str_a, str_b]);

% --- Plotting the first part of filtering process.
function plot_filter_1(f_s, fad_rate, w, H, flag_filr)
if ~flag_filr, if ishandle(11), close(11), end, return, end
dop_sprd = round(100*1.356/60*fad_rate)/100;
cut_freq = 0.588705*dop_sprd;
add = 1e5;                                  % Additional part of realization.
figure(11), subplot(221)                    % Filter Frequency Response.
plot(w*f_s/(2*pi), abs(H)), axis([0, 2*dop_sprd, 0, 1.1]), grid
title(['Filter Frequency Response, ', num2str(60*fad_rate), ' fadings per min.'])
text(dop_sprd, .5, ['Spread='  num2str(dop_sprd) 'Hz'])
text(cut_freq, 1., ['F_c_u_t=' num2str(cut_freq) 'Hz'])
xlabel('Frequency, Hz'), drawnow
% End of PLOT_FILTER_1 SubFunction.

% --- Plotting the second part of filtering process.
function plot_filter_2(f_s, q, tx, flag_filr)
if ~flag_filr, return, end
Tx = tx(end)/f_s;
num_wavs = length(q(:,1));
add = 1e5;                          % Additional part of realisation.
qh = q;                             % Most vector is for histogram.
figure(11), subplot(212)
q(:, end-add+1:end) = [];           % Delete additional part of realisation.
plot(Tx*tx/max(tx), real(q), Tx*tx/max(tx), imag(q)), grid;
title(['Normalised Skywaves Complex Coefficients q_i, i=1...', ...
        int2str(num_wavs), '.']);
xlabel('Time, s'), ylabel('Amplitude'), axis([0, Tx, -1, 1]), drawnow
[n, x] = hist([real(qh') imag(qh')], 1e2);
figure(11), subplot(222), plot(x, n), grid
title(['Histogram Of Coefficients q_i, i=1...' int2str(num_wavs) '.']), drawnow
% End of PLOT_FILTER_2 SubFunction.

% --- Realisations of transmitted & received signal & low of received signal envelope.
function plot_time(Sy, Sx, f_s, flag_time);
flag_time = flag_time(2);
if ~flag_time, if ishandle(12), close(12), end, return, end
tx = 1:length(Sx);  ty = 1:length(Sy);
Tx = tx(end)/f_s;   Ty = ty(end)/f_s;
Sx = Sx/2^15;       Sy = Sy/2^15;
Se = abs(hilbert(Sy));                      % Received signal envelope.
figure(12), subplot(211)
plot(Tx*tx/max(tx), Sx, '-b',  Ty*ty/max(ty), Sy, '-r'), grid
ymax = 1.2*max([Sx Sy]);
xlabel('Time, s'), ylabel('Amplitude'), axis([0 Ty -ymax ymax]), drawnow
title('Transmitted Signal (blue curve) & Received Signal (red curve).');
[n, x] = hist(Se, 1e4);
figure(12), subplot(212), plot(x, n, '-r'), grid
ymax = max(n);      xmax = x(max(find(n>(0.1*ymax))));
xlabel('Time, s'), ylabel('Amplitude'), title('Received Signal Envelope.')
axis([0 xmax 0 1.2*ymax]), drawnow
% End of PLOT_TIME SubFunction.

% --- Spectrogramms of transmitted (if exist) and received signal.
function plot_spec(Sy, Sx, f_s, name_dat, name_out, snr_val, flag_spec)
flag_spec = flag_spec(3);
if ~flag_spec, if ishandle(13), close(13), end, return, end
flag = 1;
if ishandle(13)     % If the Figure already exist.
    handles = get(13);
    tit = get(get(handles.Children(2),'title'),'string');
    points = regexp(tit,'''');
    name = tit(points(1)+1 : points(2)-1);
    flag = ~strcmp(name_dat, name);
end
if length(name_dat), name_dat = [' ''', upper(name_dat), '''']; end
if flag
    figure(13), subplot(211)
    specgram(Sx, 512, f_s, kaiser(5e2, 5), 475), grid
    title(['Spectrogramma Of Transmitted Signal', name_dat, '.']);
    xlabel('Time, s'), ylabel('Frequency, Hz'), drawnow
    figure(13), subplot(212)
end
specgram(Sy, 512, f_s, kaiser(5e2, 5), 475), grid
snr_string = ['SNR=' num2str(snr_val) ' dB'];
if snr_val > 99, snr_string = 'AWGN is off'; end
if length(name_out), name_out = [' ''', upper(name_out), '''']; end
title(['Spectrogramma Of Received Signal', name_out, ', ', snr_string, '.'])
xlabel('Time, s'), ylabel('Frequency, Hz')
% End of PLOT_SPEC SubFunction.

% [EOF] HFCHANNEL

% 777 Force-Majeure Cool&Happy Programming.   � Smirnoff, 2005.